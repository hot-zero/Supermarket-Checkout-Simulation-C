#include "mainwindow.h"
#include "invoicecontroller.h"
#include "ui_mainwindow.h"
#include <QStandardItemModel>
#include <QMessageBox>
#include <QDir>
#include "PaymentProcessor.h"
#include "stockcontroller.h"
#include "cardcontroller.h"
#include <QHeaderView>
#include <QDebug>
#include "tableviewmanager.h"
#include <QIcon>
#include <QFile>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),
    tableViewManager(new TableViewManager(this)),
    paymentProcessor(new PaymentProcessor()),
    invoiceController(new InvoiceController(this, paymentProcessor))
{
    ui->setupUi(this);
     setWindowTitle("SUPERMARKET CHECKOUT SIMULATION");  //  header text

    // setWindowIcon(QIcon("/icons/Supermarket-icon2.ico"));

    setupTableView();
    setupBasketTableView();

    // Set txtSubTotal, txtTax, and txtTotal as non-editable
    ui->txtSubTotal->setReadOnly(true);
    ui->txtTax->setReadOnly(true);
    ui->txtTotal->setReadOnly(true);

    // Clear the comPmethod combo box
    ui->comPmethod->setCurrentIndex(0);
    // Add this line to set the placeholder text for txtSearch
    ui->txtSearch->setPlaceholderText("Search by: Product  /  Description  / Barcode  / Price / Category");

    //----------------Buttons font and background color style-------------------

    ui->btnPay->setStyleSheet("background-color: green;color: white;");
    ui->btnExit->setStyleSheet("background-color: red;color: white");
    ui->btnInvoice->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btnRemove->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btnReset->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btnStock->setStyleSheet("background-color: blue;color: white");
    ui->btnAtbasket->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btnDot->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btnC->setStyleSheet("background-color: #a6a1a1;color: red");

    for (int i = 0; i < 10; i++) {
        QPushButton* button = this->findChild<QPushButton*>(QString("btn%1").arg(i));
        if (button) {
            button->setStyleSheet("background-color: #a6a1a1; color: white;");
        }
    }

    //-----------------------End------------------------------------------------

    //---------------Basket Image lable-----------------------------

    // Create a QLabel widget to display the image
    QLabel *imageLabel = new QLabel(this);
    // Get the application's directory
    QString appDirPath = QCoreApplication::applicationDirPath();

    QString iconPath = "/Supermarket-Checkout/icons/Supermarket-icon.ico"; // Replace with your desired file path

    QIcon icon(iconPath);

    // Check if the file exists
    if (!QFile::exists(iconPath)) {
        qDebug() << "Icon file does not exist: " << iconPath;
    } else {
        this->setWindowIcon(icon);
    }

    // Construct the image file path relative to the application's directory
    //Image path for Windows OS
    QString imagePath = appDirPath +"/icons/Basket-icon.png";

    //Image path for Mac OS
    // QString imagePath = appDirPath + "/Basket-icon.png";

    // Load the image from the constructed path

    QPixmap imagePixmap(imagePath);

    if (!imagePixmap.isNull()) {
        // Set the pixmap in the QLabel
        imageLabel->setPixmap(imagePixmap);

        // Set the position and size of the QLabel
        imageLabel->setGeometry(1025, 34, imagePixmap.width(), imagePixmap.height());

        // Add the QLabel to the main window
        imageLabel->show();
    } else {
        qDebug() << "Failed to load the image.";
        qDebug() << "Image Path: " << imagePath;

    }

    //------------End of basket Image lable------------------------------------
    // Num pad buttons to the slot
    connect(ui->btn0, &QPushButton::clicked, [this]() { onNumberButtonClicked(0); });//Button 0
    connect(ui->btn1, &QPushButton::clicked, [this]() { onNumberButtonClicked(1); });//Button 1
    connect(ui->btn2, &QPushButton::clicked, [this]() { onNumberButtonClicked(2); });//Button 2
    connect(ui->btn3, &QPushButton::clicked, [this]() { onNumberButtonClicked(3); });//Button 3
    connect(ui->btn4, &QPushButton::clicked, [this]() { onNumberButtonClicked(4); });//Button 4
    connect(ui->btn5, &QPushButton::clicked, [this]() { onNumberButtonClicked(5); });//Button 5
    connect(ui->btn6, &QPushButton::clicked, [this]() { onNumberButtonClicked(6); });//Button 6
    connect(ui->btn7, &QPushButton::clicked, [this]() { onNumberButtonClicked(7); });//Button 7
    connect(ui->btn8, &QPushButton::clicked, [this]() { onNumberButtonClicked(8); });//Button 8
    connect(ui->btn9, &QPushButton::clicked, [this]() { onNumberButtonClicked(9); });//Button 8
    connect(ui->btnDot, &QPushButton::clicked, this, &MainWindow::onDotButtonClicked);//Button .
    connect(ui->btnC, &QPushButton::clicked, this, &MainWindow::onClearButtonClicked);//Button C (clear button))
    //--------------------End of Num pad-------------------------------------------
}

MainWindow::~MainWindow()
{
    delete ui;
    delete tableViewManager;
    delete paymentProcessor;
    delete invoiceController;
}

void MainWindow::setupTableView() {

    tableViewManager->setupTableView(ui->ItemtblView);
}

void MainWindow::setupBasketTableView() {

    tableViewManager->setupBaskettblView(ui->BaskettableView);
}
//NumPad C button
void MainWindow::onClearButtonClicked()
{
    ui->txtCost->clear();
}

//Reset Button
void MainWindow::on_btnReset_clicked()
{
    ClearAndReset();
}

// Exit Button
void MainWindow::on_btnExit_clicked()
{
    QCoreApplication::quit();
}

void MainWindow::onNumberButtonClicked(int number)
{
    QString currentText = ui->txtCost->toPlainText();
    ui->txtCost->setPlainText(currentText + QString::number(number));
}

void MainWindow::onDotButtonClicked()
{
    QString currentText = ui->txtCost->toPlainText();
    if (!currentText.contains('.')) {
        ui->txtCost->setPlainText(currentText + ".");
    }
}

void MainWindow::on_btnAtbasket_clicked()

{

    // Get the selected indexes from the Items table view
    QModelIndexList selectedIndexes = ui->ItemtblView->selectionModel()->selectedRows();

    if (selectedIndexes.isEmpty()) {

        QMessageBox::information(this, "Basket is empty", "Please select one or more items to add to the basket.");

        return;
    }

    // Create a new model for the Basket QTableView
    QStandardItemModel* basketModel = dynamic_cast<QStandardItemModel*>(ui->BaskettableView->model());

    // Loop through the selected rows and copy data to the Basket
    for (const QModelIndex& index : selectedIndexes) {
        // Extract data from the selected row
        QString item = index.sibling(index.row(), 1).data().toString();   // Column 1 (Item)
        QString barcode = index.sibling(index.row(), 3).data().toString(); // Column 3 (Barcode)
        QString price = index.sibling(index.row(), 4).data().toString();   // Column 4 (Price)

        // Add the data to the Basket model
        QList<QStandardItem*> rowData;
        rowData << new QStandardItem(item) << new QStandardItem(barcode) << new QStandardItem(price);
        basketModel->appendRow(rowData);
    }
    //update count when add item to the basket table view
    on_lbl_count_linkActivated();
    // Calculate the subtotal, tax, and total

    UpdateItemCost();
    // Emit the signal with the basket model
    emit basketModelUpdated(basketModel);
}

void MainWindow::ClearAndReset()
{

    PaymentProcessor::ClearData( ui->BaskettableView,ui->ItemtblView,ui->txtCost,ui->txtSubTotal,
                                ui->txtTax,ui->txtTotal,ui->txtChange,ui -> comPmethod,ui->lbl_count);
}

void MainWindow::on_comPmethod_activated(int index)
{
    if (index == 0) // Assuming 0 represents "Cash" in the combo box
    {

    }
    else if (index == 1 && ((!ui->BaskettableView->model()->rowCount()) == 0 || !ui->txtCost->toPlainText().trimmed().isEmpty())) // Assuming 1 represents "Card" in the combo box
    {
        ui->txtCost->clear();
        ui->txtChange->clear();
        // Create an instance of CardController
        CardController *card = new CardController(this);
        // Show the new form
        card->show();  // or card->exec() for a modal form
    }
    else {
       QMessageBox::information(this, "Basket is empty", "Please ensure the basket is not empty.");
        // Reset the payment method
        ui->comPmethod->setCurrentIndex(0);
    }
}

void MainWindow::UpdateItemCost()

{
    // Call the member function on the instance
    paymentProcessor->update_ItemCost(ui->BaskettableView, ui->txtSubTotal, ui->txtTax, ui->txtTotal);
}

void MainWindow::on_btnPay_clicked()
{
    // Check if the basket is empty
    if (ui->BaskettableView->model()->rowCount() == 0) {
        QMessageBox::critical(this, "Basket is empty", "Please add items to the basket before making a payment.");
        return;
    }
    // Check if the txtCost is empty
    if (ui->txtCost->toPlainText().trimmed().isEmpty())
    {
        QMessageBox::critical(nullptr, "Pay", "Please enter the payment amount.");
        return; // Exit the function to prevent further processing
    }
    // Call the member function on the instance
    paymentProcessor->PayButton( ui->txtTotal, ui->txtCost,ui->txtChange,
                                ui->comPmethod);
    QMessageBox::information(nullptr, "Cash Payment", "Cash payment successful. Thank you for choosing our services.");

}

void MainWindow::on_btnRemove_clicked() {
    // Get the selected indexes from the Basket table view
    QModelIndexList selectedIndexes = ui->BaskettableView->selectionModel()->selectedRows();

    if (selectedIndexes.isEmpty()) {
        QMessageBox::warning(this, "Remove Item", "Please select an item to remove.");
        return;
    }
    // Ask the user for confirmation
    QMessageBox::StandardButton confirmation = QMessageBox::question(this, "Confirm Deletion",
                                                                     "Are you sure you want to delete the selected item?",
                                                                     QMessageBox::Yes | QMessageBox::No);
    if (confirmation == QMessageBox::No) {
        // If the user clicks "No", do nothing
        return;
    }

    QStandardItemModel* basketModel = qobject_cast<QStandardItemModel*>(ui->BaskettableView->model());
    if (basketModel) {
        // Iterate over the selected rows in reverse order to remove them correctly
        for (int i = selectedIndexes.size() - 1; i >= 0; --i) {
            basketModel->removeRow(selectedIndexes.at(i).row());
        }
    }
    // Emit the signal with the basket model
    emit basketModelUpdated(basketModel);
}

void MainWindow::on_lbl_count_linkActivated()
{
    int itemCount = ui->BaskettableView->model()->rowCount();
    ui->lbl_count->setText(QString::number(itemCount));
}

void MainWindow::on_btnStock_clicked()
{
    // Create an instance of StockController
    StockController *stock = new StockController(this);

    // Hide the main window
    this->close();
    // Show the stock form
    stock->show();
}

void MainWindow::onStockFormClosed()
{
    // This slot is called when the stock form is closed
    // Show the main window again
    this->show();
}

// Add this slot implementation in the MainWindow class in mainwindow.cpp
void MainWindow::on_txtSearch_textChanged()
{
    // Get the search text from the txtSearch QTextEdit
    QString searchText = ui->txtSearch->toPlainText().trimmed();

    // Get the item model from the ItemtblView
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->ItemtblView->model());

    if (!model) {
        qDebug() << "Item table model is null.";
        return;
    }

    // Clear the current selection
    ui->ItemtblView->clearSelection();

    // Iterate through all rows in the model
    for (int row = 0; row < model->rowCount(); ++row) {
        bool matchFound = false;

        // Iterate through all columns in the current row
        for (int col = 0; col < model->columnCount(); ++col) {
            // Get the data in the current cell
            QString cellText = model->index(row, col).data().toString();

            // Check if the search text is contained in the cell text (case-insensitive)
            if (cellText.toLower().contains(searchText.toLower())) {
                matchFound = true;
                break;
            }
        }
        // Set the selection for the matching row
        ui->ItemtblView->setRowHidden(row, !matchFound);
    }
}

void MainWindow::on_btnInvoice_clicked()
{
    // Check if an invoice form is already open
    if (invoiceFormOpen) {
        QMessageBox::information(this, "Invoice Form", "An invoice form is already open.");
        return;
    }
    // Create an instance of InvoiceController
    invoiceController = new InvoiceController(this, paymentProcessor);

    // Connect the closed signal of the invoice form to a slot
    connect(invoiceController, &InvoiceController::finished, this, &MainWindow::onInvoiceFormClosed);

    // Set the flag to indicate that an invoice form is open
    invoiceFormOpen = true;

    // Emit the signal with the basket model
    emit basketModelUpdated(dynamic_cast<QStandardItemModel*>(ui->BaskettableView->model()));

    // Show the invoice form
    invoiceController->show();
    // Process payment after showing the invoice form
    paymentProcessor->PayButton( ui->txtTotal, ui->txtCost,ui->txtChange,ui->comPmethod);
    on_btnReset_clicked();
}

void MainWindow::onInvoiceFormClosed()
{
    // This slot is called when the invoice form is closed
    // Set the flag to indicate that the invoice form is closed
    invoiceFormOpen = false;
}

