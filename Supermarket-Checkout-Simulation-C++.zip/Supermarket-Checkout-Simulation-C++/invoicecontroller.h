#ifndef INVOICECONTROLLER_H
#define INVOICECONTROLLER_H

#include <QDialog>
#include "PaymentProcessor.h"
#include "qlabel.h"
#include "qmainwindow.h"
#include "tableviewmanager.h"
#include <QStringList>
#include <QObject>


class PaymentProcessor;// Forward declaration
class MainWindow; // Forward declaration
namespace Ui {
class InvoiceController;
}

class InvoiceController : public QDialog
{
    Q_OBJECT

public:
    explicit InvoiceController(MainWindow* mainWindow, PaymentProcessor *paymentProcessor, QWidget* parent= nullptr);
    ~InvoiceController();
    void setupInvoicetblView();
    void updateDateLabel();
    void OrderNumber();
    void updateInvoiceBasketModel(QStandardItemModel* basketModel);
    void onPaymentSuccessful(double PaymentAmount, double sum, double tax, double change, QString PaymentMethod);
    double PaymentAmount;
    double sum;
    double tax;
    double change;

signals:
    void basketModelUpdated(QStandardItemModel* basketModel);

private slots:
    void on_InvoiceExitbtn_clicked();
    void on_Printbtn_clicked();

private:
    Ui::InvoiceController *ui;
    QLabel *InvTotallbl;
    QLabel *InvCashlbl;
    QLabel *InvChangelbl;
    TableViewManager *tableViewManager;
    PaymentProcessor *paymentProcessor;
    QMainWindow *mainWindow;
    QString PaymentMethod;

};

#endif // INVOICECONTROLLER_H
