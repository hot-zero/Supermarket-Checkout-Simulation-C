#include "cardcontroller.h"
#include "ui_cardcontroller.h"
#include "invoicecontroller.h"
#include <QDir>
#include <QMessageBox>
#include <QDate>
#include <QFile>
#include <QRegularExpression>

CardController::CardController(QWidget *parent, PaymentProcessor* processor)
    : QDialog(parent),
    ui(new Ui::CardController),
    paymentProcessor(processor)
{
    ui->setupUi(this);
     setWindowTitle("Card Payment");  //  header text
    //----------------Buttons font and background color style-------------------

    ui->btnPayCard->setStyleSheet("background-color: green;color: white;");
    ui->btnResetCard->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btnExitCard->setStyleSheet("background-color: red;color: white");

    //-----------------------End------------------------------------------------

    QString iconPath = "/Supermarket-Checkout/icons/card.png"; // Form icon
    QIcon icon(iconPath);

    // Check if the file exists
    if (!QFile::exists(iconPath)) {
        qDebug() << "Icon file does not exist: " << iconPath;
    } else {
        this->setWindowIcon(icon);
    }
}

CardController::~CardController()
{
    delete ui;
}

void CardController::on_btnExitCard_clicked()
{
    // Close the CardController form
    close();
}

void CardController::on_btnPayCard_clicked()
{
    qDebug() << "Starting on_btnPayCard_clicked";
    // Get the card number from the text input
    QString cardNumber = ui->txtCardNum->toPlainText();

    // Remove any existing spaces in the card number
    cardNumber.remove(' ');

    // Validate the card number (assuming it should be exactly 16 characters)
    if (cardNumber.length() != 16)
    {
        // Display an error message for an invalid card number
        QMessageBox::warning(this, "Invalid Card Number", "Please enter a valid 16-digit card number.");
        return;
    }

    // Get the date expiry from the text input
    QString dateExpiry = ui->txtExpiry->toPlainText();

    // Validate the date expiry (assuming it should be exactly 4 characters)
    if (dateExpiry.length() != 4 || !dateExpiry.toInt())
    {
        // Display an error message for an invalid date expiry
        QMessageBox::warning(this, "Invalid Date Expiry", "Please enter a valid 4-digit date expiry (MMYY).");
        return;
    }

    // Extract month and year from the entered date
    int enteredMonth = dateExpiry.left(2).toInt();
    int enteredYear = dateExpiry.mid(2, 2).toInt();


    // Get the current date
    QDate currentDate = QDate::currentDate();

    // Convert the entered expiry date to a QDate object
    QDate enteredExpiryDate(2000 + enteredYear, enteredMonth, 1);

    // Compare the entered expiry date with the current date
    if (enteredExpiryDate < currentDate)
    {
        // Display a message that the card has expired
        QMessageBox::information(this, "Card Expired", "The entered card has expired. Please use a valid card.");
        return;
    }

    // Get the CVV2 from the text input
    QString cvv2 = ui->txtCVV2->toPlainText();

    // Validate the CVV2 (assuming it should be exactly 3 characters)
    if (cvv2.length() != 3 || !cvv2.toInt())
    {
        // Display an error message for an invalid CVV2
        QMessageBox::warning(this, "Invalid CVV2", "Please enter a valid 3-digit CVV2.");
        return;
    }

    // Get the name on the card from the text input
    QString nameOnCard = ui->txtFullName->toPlainText();

    // Validate the name on the card (allowing letters and spaces)
    QRegularExpression rx("^[A-Za-z ]+$");  // Regular expression for letters and spaces
    if (!nameOnCard.isEmpty() && !rx.match(nameOnCard).hasMatch())
    {
        // Display an error message for an invalid name on the card
        QMessageBox::warning(this, "Invalid Name on Card", "Please enter a valid name on the card.");
        return;
    }

    QMessageBox::information(this, "Card Payment", "Card payment successful. Thank you for choosing our services.");
    close();

}

void CardController::on_btnResetCard_clicked()
{
    ui->txtCardNum->clear();
    ui->txtExpiry->clear();
    ui->txtCVV2->clear();
    ui->txtFullName->clear();
}
