#ifndef ITEM_H
#define ITEM_H

#include <QString>

class Item {
public:
    // Constructors
    Item();
    Item(const QString& id, const QString& itemName, const QString& description, const QString& barcode, double price, const QString& quantity, const QString& category);

    QString id;
    QString barcode;
    QString category;

    // Destructor
    ~Item();

    // Getters
    QString getId() const;
    QString getItemName() const;
    QString getDescription() const;
    QString getBarcode() const;
    double getPrice() const;
    QString getQuantity() const;
    QString getCategory() const;

    // Setters
    void setId(const QString& newId);
    void setItemName(const QString& newItemName);
    void setDescription(const QString& newDescription);
    void setBarcode(const QString& newBarcode);
    void setPrice(double newPrice);
    void setQuantity(const QString& newQuantity);
    void setCategory(const QString& newCategory);

private:

    QString itemName;
    QString description;
    double price;
    QString quantity;

};

// Food Item subclass
class ItemFood : public Item {
public:
    ItemFood(const QString& id, const QString& itemName, const QString& description, const QString& barcode, double price, const QString& quantity, const QString& category)
        : Item(id, itemName, description, barcode, price, quantity, category) {
    }
};

// Electronic Item subclass
class ItemElectronic : public Item {
public:
    ItemElectronic(const QString& id, const QString& itemName, const QString& description, const QString& barcode, double price, const QString& quantity, const QString& category)
        : Item(id, itemName, description, barcode, price, quantity, category) {
    }
};

// Bakery Item subclass
class Bakery : public Item {
public:
    Bakery(const QString& id, const QString& itemName, const QString& description,
           const QString& barcode, double price, const QString& quantity, const QString& category);
};

#endif // ITEM_H
