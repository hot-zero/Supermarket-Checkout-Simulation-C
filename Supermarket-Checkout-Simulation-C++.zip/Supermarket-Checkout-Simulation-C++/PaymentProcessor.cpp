#include "PaymentProcessor.h"
#include <QStandardItemModel>
#include <QTableView>
#include <QTextEdit>
#include <QMessageBox>
#include <QComboBox>
#include "invoicecontroller.h"
#include <QLabel>

PaymentProcessor::PaymentProcessor()
    : subtotal(0.0), taxRate(0.20)
{
    // Initialize members
    BaskettblView = nullptr;
    ItemtblView = nullptr;
    txtCost = nullptr;
    txtSubTotal = nullptr;
    txtTax = nullptr;
    txtTotal = nullptr;
    txtChange = nullptr;
    comPmethod = nullptr;
    lbl_count = nullptr;
}

void PaymentProcessor::update_ItemCost(QTableView* BaskettblView, QTextEdit* txtSubTotal, QTextEdit* txtTax, QTextEdit* txtTotal)
{
   QString poundSign = QString::fromUtf8("\u00A3"); // Unicode character for pound sign
    // Have a QTableView named 'basketTableView' and a QStandardItemModel as its model
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(BaskettblView->model());

    if (model)
    {
        subtotal = 0.0;  // Reset subtotal before calculating

        for (int row = 0; row < model->rowCount(); ++row)
        {
            QModelIndex itemPriceIndex = model->index(row, 2); // The price column is at index 2
            double Price = itemPriceIndex.data(Qt::DisplayRole).toDouble();
            subtotal += Price;
        }
    }

    // Calculate tax and total
    double tax = subtotal * taxRate;
    double total = subtotal + tax;

    // Update the labels with the calculated values
    txtSubTotal->setText(QString::number(subtotal, 'f', 2));
    txtTax->setText(QString::number(tax, 'f', 2));
    txtTotal->setText(QString::number(total, 'f', 2));


}

void PaymentProcessor::PayButton(QTextEdit* txtTotal, QTextEdit* txtCost, QTextEdit* txtChange, QComboBox* comPayment)
{

    QString poundSign = QString::fromUtf8("\u00A3"); // Unicode character for pound sign

    // Get the amount entered by the user for payment and total cost
    double PaymentAmount = txtTotal->toPlainText().toDouble();
    double sum = txtCost->toPlainText().toDouble();
    double change = sum - PaymentAmount;
    // Calculate tax based on the current subtotal and tax rate
    tax = subtotal * taxRate;

    QString PaymentMethod;

    if (comPayment->currentIndex() == 0) // 0 is the index for "Cash"
    {
        PaymentMethod = "Cash";

        // Check if the payment is sufficient
        if (change >= 0)
        {

            // Display the change in the 'txtChange' QTextEdit control with the pound sign
            txtChange->setPlainText(poundSign + QString::number(change, 'f', 2));
            txtChange->setStyleSheet("color: green;");
            emit PaymentSuccessful(PaymentAmount, sum, tax, change, PaymentMethod);
        }
        else
        {
            // Display a message indicating insufficient payment
            QMessageBox::critical(nullptr, "Pay", "Insufficient payment. Please provide the correct amount.");
        }
    }

    if (comPayment->currentIndex() == 1) // 1 is the index for "Card"
    {
        PaymentMethod = "Card";
    }
    emit PaymentSuccessful(PaymentAmount, sum, tax, change, PaymentMethod);
}

void PaymentProcessor::ClearData(QTableView* BaskettblView, QTableView* ItemtblView, QTextEdit* txtCost,QTextEdit* txtSubTotal,
                                 QTextEdit* txtTax,QTextEdit* txtTotal, QTextEdit* txtChange,QComboBox* comPmethod,QLabel* lbl_count)
{
    // Clear the QLineEdit controls
    txtCost->clear();
    txtSubTotal->clear();
    txtTax->clear();
    txtTotal->clear();
    txtChange->clear();

    // Reset the payment method to no selection
    comPmethod->setCurrentIndex(0);

    // Clear the Basket table view
    QStandardItemModel* basketModel = dynamic_cast<QStandardItemModel*>(BaskettblView->model());
    if (basketModel) {
        basketModel->removeRows(0, basketModel->rowCount());
    }

    // Clear the item count label
    lbl_count->setText("0");

    // Clear the selection in the Items table view (assuming it's called ui->ItemtblView)
    ItemtblView->clearSelection();
}
