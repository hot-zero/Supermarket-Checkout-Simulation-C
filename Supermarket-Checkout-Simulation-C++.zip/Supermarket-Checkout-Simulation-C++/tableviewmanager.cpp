// tableviewmanager.cpp
#include "tableviewmanager.h"
#include <QHeaderView>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include "Item.h"
#include "product.h"
#include "StockData.h"

TableViewManager::TableViewManager(QObject *parent) : QObject(parent), tableView(nullptr) {
    preloadDefaultProducts(); // Load default products
}

TableViewManager::~TableViewManager() {

}

void TableViewManager::preloadDefaultProducts() {
    StockData& stockData = StockData::getInstance();
    if (stockData.items.isEmpty()) {
        stockData.items.append(new Item("1", "Olive Oil", "Extra Virgin, 500ml", "482100", 5.99, "30", "Food"));
        stockData.items.append(new Item("2", "Whole Grain Pasta", "500g, Healthy Choice", "581236", 1.99, "50", "Food"));
        stockData.items.append(new Item("3", "Cheddar Cheese", "Matured, 250g", "783215", 3.50, "40", "Food"));
        stockData.items.append(new Item("4", "Greek Yogurt", "Low Fat, 1kg", "954321", 4.20, "60", "Food"));
        stockData.items.append(new Item("5", "Chicken Breast", "Free Range, 500g", "365214", 6.99, "35", "Food"));
        stockData.items.append(new Item("6", "Led", "Outdoor Led - 3 packs", "789012", 9.99, "10", "Electronics"));
        stockData.items.append(new Item("7", "Mouse", "Computer accessory", "785694", 6.99, "8", "Electronics"));
        stockData.items.append(new Item("8", "Keyboard", "Computer accessory", "1265782", 2.99, "10", "Electronics"));
        stockData.items.append(new Item("9", "CD", "4 packs", "987345", 4.99, "7", "Electronics"));
        stockData.items.append(new Item("10", "Fresh Baguette", "Crispy, Delightful, Perfect Companion", "659876", 1.99, "20", "Bakery"));
        stockData.items.append(new Item("11", "Chocolate Croissant", "Buttery, Chocolate-Filled, Indulgent Delight", "459876", 2.49, "30", "Bakery"));
        stockData.items.append(new Item("12", "Blueberry Muffins", "Moist, Bursting, Tasty Treat", "982363", 1.79, "25", "Bakery"));

    } else {
        qDebug() << "StockData already contains items.";
    }
}

void TableViewManager::setupTableView(QTableView *tableView)
{
    if (!tableView) {
        qDebug() << "Error: Null pointer for QTableView.";
        return;
    }

    this->tableView = tableView;
    QStandardItemModel *model = new QStandardItemModel(tableView);
    tableView->setModel(model);

    // Enable row selection
    tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    // Enable read-only mode for the table view
    tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    // Load products into the model
    loadProductsToModel(model);
}

void TableViewManager::addProduct(Product* product) {
    products.push_back(product);
    if (tableView) {
        // Update the view only if it's already set up
        QStandardItemModel *model = qobject_cast<QStandardItemModel*>(tableView->model());
        if (model) {
            loadProductsToModel(model);
        }
    }
}

void TableViewManager::loadProductsToModel(QStandardItemModel *model) {
    if (!model) {
        // If the model is null, create and set a new model
        model = new QStandardItemModel(this);
        tableView->setModel(model);
    }

    // Configure the headers and appearance of the table view
    model->setHorizontalHeaderLabels({"ID", "Product", "Description", "Barcode", "Price", "Qty", "Category"});
    tableView->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    tableView->horizontalHeader()->setStyleSheet("color: black; font-weight: bold; font-size: 14px;");
    tableView->setStyleSheet("QHeaderView::section { background-color:#b7b3b3 }; font-weight: bold");
    tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeMode::Fixed);

    // Set the size of each column
    tableView->setColumnWidth(0, 20);  // column ID
    tableView->setColumnWidth(1, 145); // column Product
    tableView->setColumnWidth(2, 260); // column Description
    tableView->setColumnWidth(3, 95); // column Barcode
    tableView->setColumnWidth(4, 50);  // column Price
    tableView->setColumnWidth(5, 50);  // column Quantity
    tableView->setColumnWidth(6, 75);  // column Category

    // Add products to the model
    for (const auto& item : StockData::getInstance().items) {
        QList<QStandardItem*> row;
        row << new QStandardItem(item->getId())
            << new QStandardItem(item->getItemName()) // Assuming Item has this method
            << new QStandardItem(item->getDescription()) // Corrected from getProductDescription
            << new QStandardItem(item->getBarcode()) // Assuming Item has this method
            << new QStandardItem(QString::number(item->getPrice())) // Assuming Item has this method
            << new QStandardItem(item->getQuantity()) // Assuming Item has this method
            << new QStandardItem(item->getCategory()); // Assuming Item has this method

        model->appendRow(row);
    }

    // Force a refresh of the TableView
    tableView->viewport()->update();
}

//-----------------------Basket Table view created--------------------------------------
void TableViewManager::setupBaskettblView(QTableView *BaskettableView)
{
    QStandardItemModel *model = new QStandardItemModel(this);
    BaskettableView->setModel(model);

    // Change the header style
    QHeaderView *horizontalHeader = BaskettableView->horizontalHeader();
    horizontalHeader->setDefaultAlignment(Qt::AlignLeft);
    horizontalHeader->setStyleSheet("color: black; font-weight: bold; font-size: 14px;");
    BaskettableView->setStyleSheet("QHeaderView::section { background-color:#b7b3b3 };font-weight: bold");
    horizontalHeader->setSectionResizeMode(QHeaderView::ResizeMode::Fixed);

    // Add column headers
    model->setHorizontalHeaderLabels(QStringList() << "Item" << "Barcode" << "Price");

    // Set the size of each column
    BaskettableView->setColumnWidth(0, 163);  // Column Item
    BaskettableView->setColumnWidth(1, 100); // Culomn Barcode
    BaskettableView->setColumnWidth(2, 50); // Culomn Price

    // Enable row selection
    BaskettableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    // Enable read-only mode for the table view
    BaskettableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
}


