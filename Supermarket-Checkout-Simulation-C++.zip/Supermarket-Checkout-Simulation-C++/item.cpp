// Item.cpp
#include "item.h"

// Default constructor
Item::Item() {
    // Initialization of member variables
    id = "";
    itemName = "";
    description = "";
    barcode = "";
    price = 0.0;
    quantity = "";
    category = "";
}

// Parameterized constructor
Item::Item(const QString& id, const QString& itemName, const QString& description, const QString& barcode, double price, const QString& quantity,const QString& category) {
    // Initialization of member variables
    this->id = id;
    this->itemName = itemName;
    this->description = description;
    this->barcode = barcode;
    this->price = price;
    this->quantity = quantity;
    this->category = category;
}


// Destructor
Item::~Item() {
}

QString Item::getId() const {
    return id;
}

QString Item::getItemName() const {
    return itemName;
}

QString Item::getDescription() const {
    return description;
}

QString Item::getBarcode() const {
    return barcode;
}

double Item::getPrice() const {
    return price;
}

QString Item::getQuantity() const {
    return quantity;
}
QString Item::getCategory() const {
    return category;
}

void Item::setId(const QString& newId) {
    id = newId;
}

void Item::setItemName(const QString& newItemName) {
    itemName = newItemName;
}

void Item::setDescription(const QString& newDescription) {
    description = newDescription;
}

void Item::setBarcode(const QString& newBarcode) {
    barcode = newBarcode;
}

void Item::setPrice(double newPrice) {
    price = newPrice;
}

void Item::setQuantity(const QString& newQuantity) {
    quantity = newQuantity;
}

void Item::setCategory(const QString& newCategory) {
    category = newCategory;
}


// Food Item subclass
class Food : public Item {
public:
    Food(const QString& id, const QString& itemName, const QString& description,
             const QString& barcode, double price, const QString& quantity, const QString& category)
        : Item(id, itemName, description, barcode, price, quantity, category) {
    }
};

// Electronic Item subclass
class Electronic : public Item {
public:
    Electronic(const QString& id, const QString& itemName, const QString& description,
                   const QString& barcode, double price, const QString& quantity, const QString& category)
        : Item(id, itemName, description, barcode, price, quantity, category) {
    }
};

// Bakery Item subclass
Bakery::Bakery(const QString& id, const QString& itemName, const QString& description,
               const QString& barcode, double price, const QString& quantity, const QString& category)
    : Item(id, itemName, description, barcode, price, quantity, category) {
}
