#ifndef TABLEVIEWMANAGER_H
#define TABLEVIEWMANAGER_H

#include "Item.h"
#include "product.h"
#include <QObject>
#include <QTableView>
#include <QStandardItemModel>
#include <QList>

class TableViewManager : public QObject
{
    Q_OBJECT
public:
    explicit TableViewManager(QObject *parent = nullptr);
    ~TableViewManager();
    void setupTableView(QTableView *tableView);
    void setupBaskettblView(QTableView *BaskettableView);
    void addProduct(Product* product); // Method to add products
    void initializeTableView(QTableView *tableView, QStandardItemModel *model);
    void preloadDefaultProducts();
    void categoryToString(QString category);

private:

    QHash<int, QStringList> DB_Items;
    QList<Item> items;  // Member variable to hold the items list
    QTableView *tableView;
    void loadProductsToModel(QStandardItemModel *model);
    std::vector<Product*> products;  // Store pointers to Product objects
};

#endif // TABLEVIEWMANAGER_H
