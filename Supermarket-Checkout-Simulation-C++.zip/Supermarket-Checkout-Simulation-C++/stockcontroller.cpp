#include "stockcontroller.h"
#include "mainwindow.h"
#include <QApplication>
#include "ui_stockcontroller.h"
#include "tableviewmanager.h"
#include "qmessagebox.h"
#include <QRegularExpression>
#include "QStandardItemModel"
#include "Item.h"
#include "StockData.h"
#include <QFile>

StockController::StockController(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::StockController),
    tableViewManager(new TableViewManager(this))  // Initialize tableViewManager in the member initializer list
{
    ui->setupUi(this);

    setWindowTitle("Stock Controller");  //  header text


    QString iconPath = "/Supermarket-Checkout/icons/Stock.png"; // Stock form icon
    QIcon icon(iconPath);

    // Check if the file exists
    if (!QFile::exists(iconPath)) {
        qDebug() << "Icon file does not exist: " << iconPath;
    } else {
        this->setWindowIcon(icon);
    }
    //----------------Buttons font and background color style-------------------

    ui->btn_NItem->setStyleSheet("background-color: green;color: white;");
    ui->btn_Save->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btn_Delete->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btnResetStock->setStyleSheet("background-color: #a6a1a1;color: white");
    ui->btn_StockExit->setStyleSheet("background-color: red;color: white");

    //-----------------------End------------------------------------------------

    setupTable(); // Call the function to set up the table view

    // Connect the clicked signal to the slot for showing details connect
    connect(ui->tbl_Scontroller, &QTableView::clicked, this, &StockController::showSelectedItemDetails);

    // Connect the clicked signal to the slot for the "New Item" button
    connect(ui->btn_NItem, &QPushButton::clicked, this, &StockController::on_btn_NItem_clicked);

    // Add this line to set the placeholder text for txtSearchStock
    ui->txtSearchStock->setPlaceholderText("Search by: Product  /  Description  / Barcode  / Price / Category");

    // Clear the combo box to remove any existing items
    ui->comboCategory->clear();

    // Set the placeholder text for the combo box
    ui->comboCategory->setPlaceholderText("Select a category");

    // Add the rest of the categories
    QStringList categories = {"Food","Bakery", "Electronics"}; // Add more categories as needed
    ui->comboCategory->addItems(categories);
}

StockController::~StockController()
{
    delete ui;
}

void StockController::on_btn_StockExit_clicked()
{
    MainWindow *main = new MainWindow(this);

    // close the stock window
    this->close();
    main->show();
}

void StockController::setupTable()
{
    tableViewManager.setupTableView(ui->tbl_Scontroller);
}

void StockController::showSelectedItemDetails(const QModelIndex &index)
{
    // Get the model associated with the table view
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(ui->tbl_Scontroller->model());
    if (!model)
        return;

    // Display the details in the respective text edits
    ui->txtID->setText(model->data(model->index(index.row(), 0)).toString());
    ui->txtItem->setText(model->data(model->index(index.row(), 1)).toString());
    ui->txtDescription->setText(model->data(model->index(index.row(), 2)).toString());
    ui->txtBarcode->setText(model->data(model->index(index.row(), 3)).toString());
    ui->txtPrice->setText(model->data(model->index(index.row(), 4)).toString());
    ui->txtQuantity->setText(model->data(model->index(index.row(), 5)).toString());
    // Set the category in the combo box
    QString category = model->data(model->index(index.row(), 6)).toString();
    int categoryIndex = ui->comboCategory->findText(category);
    if (categoryIndex != -1) {
        ui->comboCategory->setCurrentIndex(categoryIndex);
    } else {
        // Handle the case where the category is not found in the combo box
        qDebug() << "Category not found in combo box: " << category;
    }
}

void StockController::on_txtSearchStock_textChanged()
{

    // Get the search text from the txtSearch QTextEdit
    QString searchText = ui->txtSearchStock->toPlainText().trimmed();

    // Get the item model from the ItemtblView
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tbl_Scontroller->model());

    if (!model) {
        qDebug() << "Item table model is null.";
        return;
    }

    // Clear the current selection
    ui->tbl_Scontroller->clearSelection();

    // Iterate through all rows in the model
    for (int row = 0; row < model->rowCount(); ++row) {
        bool matchFound = false;

        // Iterate through all columns in the current row
        for (int col = 0; col < model->columnCount(); ++col) {
            // Get the data in the current cell
            QString cellText = model->index(row, col).data().toString();

            // Check if the search text is contained in the cell text (case-insensitive)
            if (cellText.toLower().contains(searchText.toLower())) {
                matchFound = true;
                break;
            }
        }
        // Set the selection for the matching row
        ui->tbl_Scontroller->setRowHidden(row, !matchFound);
    }

}


void StockController::on_btn_NItem_clicked() {
    // Get the data from the text edits
    QString id = ui->txtID->toPlainText();
    QString itemName = ui->txtItem->toPlainText();
    QString description = ui->txtDescription->toPlainText();
    QString barcode = ui->txtBarcode->toPlainText();
    QString price = ui->txtPrice->toPlainText();
    QString quantity = ui->txtQuantity->toPlainText();
    QString category = ui->comboCategory->currentText();

    // Validate input for each field
    if (id.isEmpty() || !id.toInt()) {
        QMessageBox::warning(this, "Invalid ID", "Please enter a valid ID (numeric value).");
        return;
    }

    if (barcode.isEmpty() || !barcode.toInt()) {
        QMessageBox::warning(this, "Invalid Barcode Number", "Please enter a valid Barcode (numeric value).");
        return;
    }

    if (price.isEmpty() || !price.toDouble()) {
        QMessageBox::warning(this, "Invalid Price", "Please enter a valid Price (numeric value).");
        return;
    }

    if (quantity.isEmpty() || !quantity.toInt()) {
        QMessageBox::warning(this, "Invalid Quantity", "Please enter a valid Quantity (numeric value).");
        return;
    }

    // Check for existing item with same ID, barcode
    const auto& items = StockData::getInstance().items;
    for (const Item* existingItem : items) {
        if (existingItem->id == id || existingItem->barcode == barcode) {
            QMessageBox::warning(this, "Duplicate Item", "An item with the same ID or BARCODE already exists.");
            return;
        }
    }

    // Create a new item dynamically
    Item* newItem = new Item(id, itemName, description, barcode, price.toDouble(), quantity, category);

    // Add the new item to the global items list in StockData
    StockData::getInstance().items.append(newItem);

    // Get the model associated with the table view
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(ui->tbl_Scontroller->model());
    if (!model) {
        qDebug() << "Item table model is null.";
        return;
    }

    // Add a new row to the model
    QList<QStandardItem*> rowData;
    rowData << new QStandardItem(id)
            << new QStandardItem(itemName)
            << new QStandardItem(description)
            << new QStandardItem(barcode)
            << new QStandardItem(price)
            << new QStandardItem(quantity)
            << new QStandardItem(category);


    model->appendRow(rowData);

    //clear the text edits for the next entry
    on_btnResetStock_clicked();
}


void StockController::on_btn_Delete_clicked() {
    QModelIndexList selectedIndexes = ui->tbl_Scontroller->selectionModel()->selectedRows();

    if (selectedIndexes.isEmpty()) {
        QMessageBox::information(this, "Remove Item", "Please select an item to remove.");
        return;
    }

    QMessageBox::StandardButton confirmation = QMessageBox::question(this, "Confirm Deletion",
                                                                     "Are you sure you want to delete the selected item?",
                                                                     QMessageBox::Yes | QMessageBox::No);

    if (confirmation == QMessageBox::No) {
        return;
    }

    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->tbl_Scontroller->model());
    if (!model) {
        qDebug() << "Item table model is null.";
        return;
    }

    auto& items = StockData::getInstance().items;

    for (int i = selectedIndexes.size() - 1; i >= 0; --i) {
        int row = selectedIndexes.at(i).row();
        QString barcode = model->item(row, 3)->text(); // Assuming barcode is in column 3

        auto it = std::find_if(items.begin(), items.end(),
                               [&](const Item* item) { return item->getBarcode() == barcode; });
        if (it != items.end()) {
            delete *it;  // If dynamically allocated
            items.erase(it);
        }

        model->removeRow(row);
    }
}

void StockController::updateDetails(const QString& id, const QString& pName, const QString& pDescription,
                                    const QString& pBarcode, double pPrice, const QString& pQuantity, const QString& pCategory) {

    QList<Item*>& items = StockData::getInstance().items;

    for (int i = 0; i < items.size(); ++i) {
        if (items[i]->getBarcode() == pBarcode) {
            items[i]->setId(id);
            items[i]->setItemName(pName);
            items[i]->setDescription(pDescription);
            items[i]->setBarcode(pBarcode);
            items[i]->setPrice(pPrice);
            items[i]->setQuantity(pQuantity);
            items[i]->setCategory(pCategory);
            break; // Assuming barcode is unique, so we can exit the loop
        }
    }

}

void StockController::on_btn_Save_clicked() {
    // Get the data from the text edits
    QString id = ui->txtID->toPlainText();
    QString item = ui->txtItem->toPlainText();
    QString description = ui->txtDescription->toPlainText();
    QString barcode = ui->txtBarcode->toPlainText();
    QString price = ui->txtPrice->toPlainText();
    QString quantity = ui->txtQuantity->toPlainText();
    QString category = ui->comboCategory->currentText();

    // Validate input for each field
    if (id.isEmpty() || !id.toInt()) {
        QMessageBox::warning(this, "Invalid ID", "Please enter a valid ID (numeric value).");
        return;
    }

    if (barcode.isEmpty() || !barcode.toInt()) {
        QMessageBox::warning(this, "Invalid Barcode Number", "Please enter a valid Barcode (numeric value).");
        return;
    }

    if (price.isEmpty() || !price.toDouble()) {
        QMessageBox::warning(this, "Invalid Price", "Please enter a valid Price (numeric value).");
        return;
    }

    if (quantity.isEmpty() || !quantity.toInt()) {
        QMessageBox::warning(this, "Invalid Quantity", "Please enter a valid Quantity (numeric value).");
        return;
    }

    // Get the selected row
    QModelIndex selectedIndex = ui->tbl_Scontroller->selectionModel()->currentIndex();
    if (!selectedIndex.isValid()) {
        QMessageBox::information(this, "Update Item", "Please select an item to update.");
        return;
    }

    // Get the model associated with the table view
    QStandardItemModel *model = qobject_cast<QStandardItemModel*>(ui->tbl_Scontroller->model());
    if (!model) {
        qDebug() << "Item table model is null.";
        return;
    }

    // Update the data in the model
    model->setData(model->index(selectedIndex.row(), 0), id);
    model->setData(model->index(selectedIndex.row(), 1), item);
    model->setData(model->index(selectedIndex.row(), 2), description);
    model->setData(model->index(selectedIndex.row(), 3), barcode);
    model->setData(model->index(selectedIndex.row(), 4), price);
    model->setData(model->index(selectedIndex.row(), 5), quantity);
    model->setData(model->index(selectedIndex.row(), 6), category);
    // Update the details in StockData's items list
    updateDetails(id, item, description, barcode, price.toDouble(), quantity, category);

    // Show a message that the item has been successfully saved
    QMessageBox::information(this, "Item Saved", "The item has been successfully saved.");
}

void StockController::on_btnResetStock_clicked()
{
    ui->txtID->clear();
    ui->txtItem->clear();
    ui->txtDescription->clear();
    ui->txtBarcode->clear();
    ui->txtPrice->clear();
    ui->txtQuantity->clear();
    // Reset the combo box to the placeholder or default value
    ui->comboCategory->setCurrentIndex(-1);
}

