#ifndef PRODUCT_H
#define PRODUCT_H

#include "item.h"
#include <QString>


// Base class for products
class Product : public Item {
private:
    QString id;
    QString name;
    QString description;
    QString barcode;
    double price;
    QString quantity;
    QString category;

public:
    Product(QString id, QString name, QString description, QString barcode, double price, QString quantity, QString category);
    virtual ~Product();

    QString getProductId() const;
    QString getProductName() const;
    QString getProductDescription() const;
    QString getProductBarcode() const;
    double getProductPrice() const;
    QString getProductQuantity() const;
    QString getProductCategory() const;
    void setProductCategory(QString newProductCategory);
};

class FoodProduct : public Product {
public:
    FoodProduct(const QString& id, const QString& name, const QString& description, const QString& barcode,
                double price, const QString& quantity, QString category);
    // other members...
};


class ElectronicProduct : public Product {
public:
    ElectronicProduct(const QString& id, const QString& name, const QString& description, const QString& barcode,
                      double price, const QString& quantity, QString category);
    // other members...
};



#endif // PRODUCT_H
