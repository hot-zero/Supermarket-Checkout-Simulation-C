/********************************************************************************
** Form generated from reading UI file 'stockcontroller.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STOCKCONTROLLER_H
#define UI_STOCKCONTROLLER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_StockController
{
public:
    QFrame *frame;
    QLabel *lbl_Quantity;
    QLabel *lbl_Price;
    QLabel *lbl_Barcode;
    QLabel *lbl_Description;
    QLabel *lbl_Item;
    QLabel *lbl_ID;
    QTextEdit *txtID;
    QTextEdit *txtItem;
    QTextEdit *txtDescription;
    QTextEdit *txtBarcode;
    QTextEdit *txtPrice;
    QTextEdit *txtQuantity;
    QPushButton *btn_NItem;
    QPushButton *btn_Save;
    QPushButton *btn_Delete;
    QPushButton *btn_StockExit;
    QPushButton *btnResetStock;
    QLabel *lbl_Quantity_2;
    QComboBox *comboCategory;
    QLabel *label_7;
    QTableView *tbl_Scontroller;
    QTextEdit *txtSearchStock;

    void setupUi(QDialog *StockController)
    {
        if (StockController->objectName().isEmpty())
            StockController->setObjectName("StockController");
        StockController->resize(849, 955);
        frame = new QFrame(StockController);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(20, 50, 761, 521));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        lbl_Quantity = new QLabel(frame);
        lbl_Quantity->setObjectName("lbl_Quantity");
        lbl_Quantity->setGeometry(QRect(10, 340, 111, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri")});
        font.setPointSize(20);
        font.setBold(true);
        lbl_Quantity->setFont(font);
        lbl_Price = new QLabel(frame);
        lbl_Price->setObjectName("lbl_Price");
        lbl_Price->setGeometry(QRect(10, 290, 81, 31));
        lbl_Price->setFont(font);
        lbl_Barcode = new QLabel(frame);
        lbl_Barcode->setObjectName("lbl_Barcode");
        lbl_Barcode->setGeometry(QRect(10, 240, 111, 31));
        lbl_Barcode->setFont(font);
        lbl_Description = new QLabel(frame);
        lbl_Description->setObjectName("lbl_Description");
        lbl_Description->setGeometry(QRect(10, 130, 131, 31));
        lbl_Description->setFont(font);
        lbl_Item = new QLabel(frame);
        lbl_Item->setObjectName("lbl_Item");
        lbl_Item->setGeometry(QRect(10, 80, 81, 31));
        lbl_Item->setFont(font);
        lbl_ID = new QLabel(frame);
        lbl_ID->setObjectName("lbl_ID");
        lbl_ID->setGeometry(QRect(10, 30, 81, 31));
        lbl_ID->setFont(font);
        txtID = new QTextEdit(frame);
        txtID->setObjectName("txtID");
        txtID->setGeometry(QRect(190, 30, 400, 41));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Calibri")});
        font1.setPointSize(17);
        font1.setBold(true);
        txtID->setFont(font1);
        txtItem = new QTextEdit(frame);
        txtItem->setObjectName("txtItem");
        txtItem->setGeometry(QRect(190, 80, 400, 41));
        txtItem->setFont(font1);
        txtDescription = new QTextEdit(frame);
        txtDescription->setObjectName("txtDescription");
        txtDescription->setGeometry(QRect(190, 130, 400, 101));
        txtDescription->setFont(font1);
        txtBarcode = new QTextEdit(frame);
        txtBarcode->setObjectName("txtBarcode");
        txtBarcode->setGeometry(QRect(190, 240, 400, 41));
        txtBarcode->setFont(font1);
        txtPrice = new QTextEdit(frame);
        txtPrice->setObjectName("txtPrice");
        txtPrice->setGeometry(QRect(190, 290, 400, 41));
        txtPrice->setFont(font1);
        txtQuantity = new QTextEdit(frame);
        txtQuantity->setObjectName("txtQuantity");
        txtQuantity->setGeometry(QRect(190, 340, 400, 41));
        txtQuantity->setFont(font1);
        btn_NItem = new QPushButton(frame);
        btn_NItem->setObjectName("btn_NItem");
        btn_NItem->setGeometry(QRect(10, 470, 101, 41));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Calibri")});
        font2.setPointSize(14);
        font2.setBold(true);
        btn_NItem->setFont(font2);
        btn_Save = new QPushButton(frame);
        btn_Save->setObjectName("btn_Save");
        btn_Save->setGeometry(QRect(120, 470, 101, 41));
        btn_Save->setFont(font2);
        btn_Delete = new QPushButton(frame);
        btn_Delete->setObjectName("btn_Delete");
        btn_Delete->setGeometry(QRect(340, 470, 101, 41));
        btn_Delete->setFont(font2);
        btn_StockExit = new QPushButton(frame);
        btn_StockExit->setObjectName("btn_StockExit");
        btn_StockExit->setGeometry(QRect(450, 470, 101, 41));
        btn_StockExit->setFont(font2);
        btnResetStock = new QPushButton(frame);
        btnResetStock->setObjectName("btnResetStock");
        btnResetStock->setGeometry(QRect(230, 470, 101, 41));
        btnResetStock->setFont(font2);
        lbl_Quantity_2 = new QLabel(frame);
        lbl_Quantity_2->setObjectName("lbl_Quantity_2");
        lbl_Quantity_2->setGeometry(QRect(10, 400, 111, 41));
        lbl_Quantity_2->setFont(font);
        comboCategory = new QComboBox(frame);
        comboCategory->setObjectName("comboCategory");
        comboCategory->setGeometry(QRect(190, 400, 401, 41));
        label_7 = new QLabel(StockController);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(20, 0, 411, 61));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Calibri")});
        font3.setPointSize(36);
        font3.setBold(true);
        label_7->setFont(font3);
        tbl_Scontroller = new QTableView(StockController);
        tbl_Scontroller->setObjectName("tbl_Scontroller");
        tbl_Scontroller->setGeometry(QRect(20, 580, 761, 290));
        txtSearchStock = new QTextEdit(StockController);
        txtSearchStock->setObjectName("txtSearchStock");
        txtSearchStock->setGeometry(QRect(20, 890, 541, 51));
        txtSearchStock->setFont(font2);
        txtSearchStock->setFrameShape(QFrame::StyledPanel);

        retranslateUi(StockController);

        QMetaObject::connectSlotsByName(StockController);
    } // setupUi

    void retranslateUi(QDialog *StockController)
    {
        StockController->setWindowTitle(QCoreApplication::translate("StockController", "Dialog", nullptr));
        lbl_Quantity->setText(QCoreApplication::translate("StockController", "Quantity", nullptr));
        lbl_Price->setText(QCoreApplication::translate("StockController", "Price", nullptr));
        lbl_Barcode->setText(QCoreApplication::translate("StockController", "Barcode", nullptr));
        lbl_Description->setText(QCoreApplication::translate("StockController", "Description", nullptr));
        lbl_Item->setText(QCoreApplication::translate("StockController", "Item", nullptr));
        lbl_ID->setText(QCoreApplication::translate("StockController", "ID", nullptr));
        btn_NItem->setText(QCoreApplication::translate("StockController", "New Item", nullptr));
        btn_Save->setText(QCoreApplication::translate("StockController", "Save", nullptr));
        btn_Delete->setText(QCoreApplication::translate("StockController", "Delete", nullptr));
        btn_StockExit->setText(QCoreApplication::translate("StockController", "Exit", nullptr));
        btnResetStock->setText(QCoreApplication::translate("StockController", "Reset", nullptr));
        lbl_Quantity_2->setText(QCoreApplication::translate("StockController", "Category", nullptr));
        label_7->setText(QCoreApplication::translate("StockController", "<html><head/><body><p><span style=\" color:#e20000;\">STOCK CONTROLLER</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StockController: public Ui_StockController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STOCKCONTROLLER_H
