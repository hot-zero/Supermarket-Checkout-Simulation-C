/********************************************************************************
** Form generated from reading UI file 'invoicecontroller.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INVOICECONTROLLER_H
#define UI_INVOICECONTROLLER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_InvoiceController
{
public:
    QLabel *Date;
    QLabel *OrderLabel;
    QLabel *label;
    QTableView *InvoicetblView;
    QPushButton *Printbtn;
    QPushButton *InvoiceExitbtn;
    QLabel *InvoiceHeaderlbl;
    QLabel *InvTotallbl;
    QLabel *InvCashlbl;
    QLabel *InvChangelbl;
    QLabel *Datelbl;
    QLabel *OrderNumlbl;
    QLabel *InvCombolbl;
    QLabel *InvTaxlbl;

    void setupUi(QDialog *InvoiceController)
    {
        if (InvoiceController->objectName().isEmpty())
            InvoiceController->setObjectName("InvoiceController");
        InvoiceController->resize(367, 805);
        Date = new QLabel(InvoiceController);
        Date->setObjectName("Date");
        Date->setGeometry(QRect(20, 70, 49, 16));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri")});
        font.setPointSize(12);
        font.setBold(true);
        Date->setFont(font);
        OrderLabel = new QLabel(InvoiceController);
        OrderLabel->setObjectName("OrderLabel");
        OrderLabel->setGeometry(QRect(20, 100, 111, 16));
        OrderLabel->setFont(font);
        label = new QLabel(InvoiceController);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 130, 331, 16));
        InvoicetblView = new QTableView(InvoiceController);
        InvoicetblView->setObjectName("InvoicetblView");
        InvoicetblView->setGeometry(QRect(20, 160, 331, 341));
        Printbtn = new QPushButton(InvoiceController);
        Printbtn->setObjectName("Printbtn");
        Printbtn->setGeometry(QRect(20, 750, 101, 41));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Calibri")});
        font1.setPointSize(14);
        font1.setBold(true);
        Printbtn->setFont(font1);
        InvoiceExitbtn = new QPushButton(InvoiceController);
        InvoiceExitbtn->setObjectName("InvoiceExitbtn");
        InvoiceExitbtn->setGeometry(QRect(250, 750, 101, 41));
        InvoiceExitbtn->setFont(font1);
        InvoiceHeaderlbl = new QLabel(InvoiceController);
        InvoiceHeaderlbl->setObjectName("InvoiceHeaderlbl");
        InvoiceHeaderlbl->setGeometry(QRect(20, 10, 331, 41));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Calibri")});
        font2.setPointSize(24);
        font2.setBold(true);
        InvoiceHeaderlbl->setFont(font2);
        InvTotallbl = new QLabel(InvoiceController);
        InvTotallbl->setObjectName("InvTotallbl");
        InvTotallbl->setGeometry(QRect(20, 580, 231, 16));
        InvTotallbl->setFont(font);
        InvCashlbl = new QLabel(InvoiceController);
        InvCashlbl->setObjectName("InvCashlbl");
        InvCashlbl->setGeometry(QRect(20, 660, 221, 16));
        InvCashlbl->setFont(font);
        InvChangelbl = new QLabel(InvoiceController);
        InvChangelbl->setObjectName("InvChangelbl");
        InvChangelbl->setGeometry(QRect(20, 700, 261, 21));
        InvChangelbl->setFont(font);
        Datelbl = new QLabel(InvoiceController);
        Datelbl->setObjectName("Datelbl");
        Datelbl->setGeometry(QRect(140, 70, 211, 20));
        Datelbl->setFont(font);
        OrderNumlbl = new QLabel(InvoiceController);
        OrderNumlbl->setObjectName("OrderNumlbl");
        OrderNumlbl->setGeometry(QRect(140, 100, 111, 16));
        OrderNumlbl->setFont(font);
        InvCombolbl = new QLabel(InvoiceController);
        InvCombolbl->setObjectName("InvCombolbl");
        InvCombolbl->setGeometry(QRect(20, 540, 261, 21));
        InvCombolbl->setFont(font);
        InvTaxlbl = new QLabel(InvoiceController);
        InvTaxlbl->setObjectName("InvTaxlbl");
        InvTaxlbl->setGeometry(QRect(20, 620, 231, 16));
        InvTaxlbl->setFont(font);

        retranslateUi(InvoiceController);

        QMetaObject::connectSlotsByName(InvoiceController);
    } // setupUi

    void retranslateUi(QDialog *InvoiceController)
    {
        InvoiceController->setWindowTitle(QCoreApplication::translate("InvoiceController", "Dialog", nullptr));
        Date->setText(QCoreApplication::translate("InvoiceController", "Date:", nullptr));
        OrderLabel->setText(QCoreApplication::translate("InvoiceController", "Order Number:", nullptr));
        label->setText(QCoreApplication::translate("InvoiceController", "=========================================", nullptr));
        Printbtn->setText(QCoreApplication::translate("InvoiceController", "Print", nullptr));
        InvoiceExitbtn->setText(QCoreApplication::translate("InvoiceController", "Exit", nullptr));
        InvoiceHeaderlbl->setText(QCoreApplication::translate("InvoiceController", "<html><head/><body><p><span style=\" color:#3d9d14;\">SUPERMARKET INVOICE</span></p></body></html>", nullptr));
        InvTotallbl->setText(QString());
        InvCashlbl->setText(QString());
        InvChangelbl->setText(QString());
        Datelbl->setText(QString());
        OrderNumlbl->setText(QString());
        InvCombolbl->setText(QString());
        InvTaxlbl->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class InvoiceController: public Ui_InvoiceController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INVOICECONTROLLER_H
