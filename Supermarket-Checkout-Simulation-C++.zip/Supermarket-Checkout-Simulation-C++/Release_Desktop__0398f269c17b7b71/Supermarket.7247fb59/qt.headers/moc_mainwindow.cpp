/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "basketModelUpdated",
    "",
    "QStandardItemModel*",
    "basketModel",
    "PaymentSuccessful",
    "PaymentAmount",
    "sum",
    "tax",
    "change",
    "QString&",
    "PaymentMethod",
    "onNumberButtonClicked",
    "number",
    "onDotButtonClicked",
    "onClearButtonClicked",
    "on_comPmethod_activated",
    "index",
    "on_btnAtbasket_clicked",
    "on_btnExit_clicked",
    "on_btnPay_clicked",
    "on_txtSearch_textChanged",
    "on_btnRemove_clicked",
    "on_lbl_count_linkActivated",
    "on_btnStock_clicked",
    "on_btnReset_clicked",
    "on_btnInvoice_clicked",
    "onInvoiceFormClosed"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[56];
    char stringdata0[11];
    char stringdata1[19];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[12];
    char stringdata5[18];
    char stringdata6[14];
    char stringdata7[4];
    char stringdata8[4];
    char stringdata9[7];
    char stringdata10[9];
    char stringdata11[14];
    char stringdata12[22];
    char stringdata13[7];
    char stringdata14[19];
    char stringdata15[21];
    char stringdata16[24];
    char stringdata17[6];
    char stringdata18[23];
    char stringdata19[19];
    char stringdata20[18];
    char stringdata21[25];
    char stringdata22[21];
    char stringdata23[27];
    char stringdata24[20];
    char stringdata25[20];
    char stringdata26[22];
    char stringdata27[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 18),  // "basketModelUpdated"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 19),  // "QStandardItemModel*"
        QT_MOC_LITERAL(51, 11),  // "basketModel"
        QT_MOC_LITERAL(63, 17),  // "PaymentSuccessful"
        QT_MOC_LITERAL(81, 13),  // "PaymentAmount"
        QT_MOC_LITERAL(95, 3),  // "sum"
        QT_MOC_LITERAL(99, 3),  // "tax"
        QT_MOC_LITERAL(103, 6),  // "change"
        QT_MOC_LITERAL(110, 8),  // "QString&"
        QT_MOC_LITERAL(119, 13),  // "PaymentMethod"
        QT_MOC_LITERAL(133, 21),  // "onNumberButtonClicked"
        QT_MOC_LITERAL(155, 6),  // "number"
        QT_MOC_LITERAL(162, 18),  // "onDotButtonClicked"
        QT_MOC_LITERAL(181, 20),  // "onClearButtonClicked"
        QT_MOC_LITERAL(202, 23),  // "on_comPmethod_activated"
        QT_MOC_LITERAL(226, 5),  // "index"
        QT_MOC_LITERAL(232, 22),  // "on_btnAtbasket_clicked"
        QT_MOC_LITERAL(255, 18),  // "on_btnExit_clicked"
        QT_MOC_LITERAL(274, 17),  // "on_btnPay_clicked"
        QT_MOC_LITERAL(292, 24),  // "on_txtSearch_textChanged"
        QT_MOC_LITERAL(317, 20),  // "on_btnRemove_clicked"
        QT_MOC_LITERAL(338, 26),  // "on_lbl_count_linkActivated"
        QT_MOC_LITERAL(365, 19),  // "on_btnStock_clicked"
        QT_MOC_LITERAL(385, 19),  // "on_btnReset_clicked"
        QT_MOC_LITERAL(405, 21),  // "on_btnInvoice_clicked"
        QT_MOC_LITERAL(427, 19)   // "onInvoiceFormClosed"
    },
    "MainWindow",
    "basketModelUpdated",
    "",
    "QStandardItemModel*",
    "basketModel",
    "PaymentSuccessful",
    "PaymentAmount",
    "sum",
    "tax",
    "change",
    "QString&",
    "PaymentMethod",
    "onNumberButtonClicked",
    "number",
    "onDotButtonClicked",
    "onClearButtonClicked",
    "on_comPmethod_activated",
    "index",
    "on_btnAtbasket_clicked",
    "on_btnExit_clicked",
    "on_btnPay_clicked",
    "on_txtSearch_textChanged",
    "on_btnRemove_clicked",
    "on_lbl_count_linkActivated",
    "on_btnStock_clicked",
    "on_btnReset_clicked",
    "on_btnInvoice_clicked",
    "onInvoiceFormClosed"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  110,    2, 0x06,    1 /* Public */,
       5,    5,  113,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      12,    1,  124,    2, 0x08,    9 /* Private */,
      14,    0,  127,    2, 0x08,   11 /* Private */,
      15,    0,  128,    2, 0x08,   12 /* Private */,
      16,    1,  129,    2, 0x08,   13 /* Private */,
      18,    0,  132,    2, 0x08,   15 /* Private */,
      19,    0,  133,    2, 0x08,   16 /* Private */,
      20,    0,  134,    2, 0x08,   17 /* Private */,
      21,    0,  135,    2, 0x08,   18 /* Private */,
      22,    0,  136,    2, 0x08,   19 /* Private */,
      23,    0,  137,    2, 0x08,   20 /* Private */,
      24,    0,  138,    2, 0x08,   21 /* Private */,
      25,    0,  139,    2, 0x08,   22 /* Private */,
      26,    0,  140,    2, 0x08,   23 /* Private */,
      27,    0,  141,    2, 0x08,   24 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double, 0x80000000 | 10,    6,    7,    8,    9,   11,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'basketModelUpdated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStandardItemModel *, std::false_type>,
        // method 'PaymentSuccessful'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'onNumberButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onDotButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onClearButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_comPmethod_activated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_btnAtbasket_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnExit_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnPay_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_txtSearch_textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnRemove_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lbl_count_linkActivated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnStock_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnReset_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnInvoice_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onInvoiceFormClosed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->basketModelUpdated((*reinterpret_cast< std::add_pointer_t<QStandardItemModel*>>(_a[1]))); break;
        case 1: _t->PaymentSuccessful((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[5]))); break;
        case 2: _t->onNumberButtonClicked((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->onDotButtonClicked(); break;
        case 4: _t->onClearButtonClicked(); break;
        case 5: _t->on_comPmethod_activated((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->on_btnAtbasket_clicked(); break;
        case 7: _t->on_btnExit_clicked(); break;
        case 8: _t->on_btnPay_clicked(); break;
        case 9: _t->on_txtSearch_textChanged(); break;
        case 10: _t->on_btnRemove_clicked(); break;
        case 11: _t->on_lbl_count_linkActivated(); break;
        case 12: _t->on_btnStock_clicked(); break;
        case 13: _t->on_btnReset_clicked(); break;
        case 14: _t->on_btnInvoice_clicked(); break;
        case 15: _t->onInvoiceFormClosed(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QStandardItemModel* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QStandardItemModel * );
            if (_t _q_method = &MainWindow::basketModelUpdated; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(double , double , double , double , QString & );
            if (_t _q_method = &MainWindow::PaymentSuccessful; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::basketModelUpdated(QStandardItemModel * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::PaymentSuccessful(double _t1, double _t2, double _t3, double _t4, QString & _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
