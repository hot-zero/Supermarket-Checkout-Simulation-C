/********************************************************************************
** Form generated from reading UI file 'cardcontroller.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CARDCONTROLLER_H
#define UI_CARDCONTROLLER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_CardController
{
public:
    QTextEdit *txtCardNum;
    QTextEdit *txtExpiry;
    QTextEdit *txtCVV2;
    QTextEdit *txtFullName;
    QPushButton *btnPayCard;
    QPushButton *btnResetCard;
    QPushButton *btnExitCard;
    QLabel *lbl_CardPayment;
    QLabel *lblCardNum;
    QLabel *lblDateExpiry;
    QLabel *lblCVV2;
    QLabel *lblFullName;

    void setupUi(QDialog *CardController)
    {
        if (CardController->objectName().isEmpty())
            CardController->setObjectName("CardController");
        CardController->resize(583, 412);
        txtCardNum = new QTextEdit(CardController);
        txtCardNum->setObjectName("txtCardNum");
        txtCardNum->setGeometry(QRect(20, 100, 321, 41));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri")});
        font.setPointSize(17);
        font.setBold(true);
        txtCardNum->setFont(font);
        txtExpiry = new QTextEdit(CardController);
        txtExpiry->setObjectName("txtExpiry");
        txtExpiry->setGeometry(QRect(20, 190, 111, 41));
        txtExpiry->setFont(font);
        txtCVV2 = new QTextEdit(CardController);
        txtCVV2->setObjectName("txtCVV2");
        txtCVV2->setGeometry(QRect(230, 190, 111, 41));
        txtCVV2->setFont(font);
        txtFullName = new QTextEdit(CardController);
        txtFullName->setObjectName("txtFullName");
        txtFullName->setGeometry(QRect(20, 270, 321, 41));
        txtFullName->setFont(font);
        btnPayCard = new QPushButton(CardController);
        btnPayCard->setObjectName("btnPayCard");
        btnPayCard->setGeometry(QRect(20, 340, 101, 41));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Calibri")});
        font1.setPointSize(14);
        font1.setBold(true);
        btnPayCard->setFont(font1);
        btnResetCard = new QPushButton(CardController);
        btnResetCard->setObjectName("btnResetCard");
        btnResetCard->setGeometry(QRect(130, 340, 101, 41));
        btnResetCard->setFont(font1);
        btnExitCard = new QPushButton(CardController);
        btnExitCard->setObjectName("btnExitCard");
        btnExitCard->setGeometry(QRect(240, 340, 101, 41));
        btnExitCard->setFont(font1);
        lbl_CardPayment = new QLabel(CardController);
        lbl_CardPayment->setObjectName("lbl_CardPayment");
        lbl_CardPayment->setGeometry(QRect(20, 0, 241, 51));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Calibri")});
        font2.setPointSize(26);
        font2.setBold(true);
        lbl_CardPayment->setFont(font2);
        lblCardNum = new QLabel(CardController);
        lblCardNum->setObjectName("lblCardNum");
        lblCardNum->setGeometry(QRect(20, 75, 121, 21));
        lblCardNum->setFont(font1);
        lblDateExpiry = new QLabel(CardController);
        lblDateExpiry->setObjectName("lblDateExpiry");
        lblDateExpiry->setGeometry(QRect(20, 165, 101, 21));
        lblDateExpiry->setFont(font1);
        lblCVV2 = new QLabel(CardController);
        lblCVV2->setObjectName("lblCVV2");
        lblCVV2->setGeometry(QRect(230, 166, 101, 20));
        lblCVV2->setFont(font1);
        lblFullName = new QLabel(CardController);
        lblFullName->setObjectName("lblFullName");
        lblFullName->setGeometry(QRect(20, 250, 131, 16));
        lblFullName->setFont(font1);

        retranslateUi(CardController);

        QMetaObject::connectSlotsByName(CardController);
    } // setupUi

    void retranslateUi(QDialog *CardController)
    {
        CardController->setWindowTitle(QCoreApplication::translate("CardController", "Dialog", nullptr));
        btnPayCard->setText(QCoreApplication::translate("CardController", "PAY", nullptr));
        btnResetCard->setText(QCoreApplication::translate("CardController", "RESET", nullptr));
        btnExitCard->setText(QCoreApplication::translate("CardController", "EXIT", nullptr));
        lbl_CardPayment->setText(QCoreApplication::translate("CardController", "<html><head/><body><p><span style=\" color:#ff2600;\">CARD PAYMENT</span></p></body></html>", nullptr));
        lblCardNum->setText(QCoreApplication::translate("CardController", "Card Number:", nullptr));
        lblDateExpiry->setText(QCoreApplication::translate("CardController", "Date Expiry:", nullptr));
        lblCVV2->setText(QCoreApplication::translate("CardController", "CVV2:", nullptr));
        lblFullName->setText(QCoreApplication::translate("CardController", "Name on Card:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CardController: public Ui_CardController {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CARDCONTROLLER_H
