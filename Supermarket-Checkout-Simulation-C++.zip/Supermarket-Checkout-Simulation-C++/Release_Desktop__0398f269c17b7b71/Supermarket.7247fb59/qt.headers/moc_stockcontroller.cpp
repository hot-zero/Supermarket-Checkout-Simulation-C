/****************************************************************************
** Meta object code from reading C++ file 'stockcontroller.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../stockcontroller.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'stockcontroller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSStockControllerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSStockControllerENDCLASS = QtMocHelpers::stringData(
    "StockController",
    "on_btn_StockExit_clicked",
    "",
    "showSelectedItemDetails",
    "QModelIndex",
    "index",
    "on_txtSearchStock_textChanged",
    "on_btn_Delete_clicked",
    "on_btn_Save_clicked",
    "on_btnResetStock_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSStockControllerENDCLASS_t {
    uint offsetsAndSizes[20];
    char stringdata0[16];
    char stringdata1[25];
    char stringdata2[1];
    char stringdata3[24];
    char stringdata4[12];
    char stringdata5[6];
    char stringdata6[30];
    char stringdata7[22];
    char stringdata8[20];
    char stringdata9[25];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSStockControllerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSStockControllerENDCLASS_t qt_meta_stringdata_CLASSStockControllerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 15),  // "StockController"
        QT_MOC_LITERAL(16, 24),  // "on_btn_StockExit_clicked"
        QT_MOC_LITERAL(41, 0),  // ""
        QT_MOC_LITERAL(42, 23),  // "showSelectedItemDetails"
        QT_MOC_LITERAL(66, 11),  // "QModelIndex"
        QT_MOC_LITERAL(78, 5),  // "index"
        QT_MOC_LITERAL(84, 29),  // "on_txtSearchStock_textChanged"
        QT_MOC_LITERAL(114, 21),  // "on_btn_Delete_clicked"
        QT_MOC_LITERAL(136, 19),  // "on_btn_Save_clicked"
        QT_MOC_LITERAL(156, 24)   // "on_btnResetStock_clicked"
    },
    "StockController",
    "on_btn_StockExit_clicked",
    "",
    "showSelectedItemDetails",
    "QModelIndex",
    "index",
    "on_txtSearchStock_textChanged",
    "on_btn_Delete_clicked",
    "on_btn_Save_clicked",
    "on_btnResetStock_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSStockControllerENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   50,    2, 0x08,    1 /* Private */,
       3,    1,   51,    2, 0x08,    2 /* Private */,
       6,    0,   54,    2, 0x08,    4 /* Private */,
       7,    0,   55,    2, 0x08,    5 /* Private */,
       8,    0,   56,    2, 0x08,    6 /* Private */,
       9,    0,   57,    2, 0x08,    7 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject StockController::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSStockControllerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSStockControllerENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSStockControllerENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<StockController, std::true_type>,
        // method 'on_btn_StockExit_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showSelectedItemDetails'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_txtSearchStock_textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btn_Delete_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btn_Save_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnResetStock_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void StockController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<StockController *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_btn_StockExit_clicked(); break;
        case 1: _t->showSelectedItemDetails((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 2: _t->on_txtSearchStock_textChanged(); break;
        case 3: _t->on_btn_Delete_clicked(); break;
        case 4: _t->on_btn_Save_clicked(); break;
        case 5: _t->on_btnResetStock_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *StockController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StockController::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSStockControllerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int StockController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 6;
    }
    return _id;
}
QT_WARNING_POP
