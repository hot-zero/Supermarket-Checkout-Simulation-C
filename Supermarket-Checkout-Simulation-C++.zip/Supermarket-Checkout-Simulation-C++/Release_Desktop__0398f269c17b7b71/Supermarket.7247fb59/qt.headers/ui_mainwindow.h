/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *MainHeaderlbl;
    QFrame *NumPad_Frame;
    QPushButton *btn7;
    QPushButton *btn8;
    QPushButton *btn9;
    QPushButton *btn4;
    QPushButton *btn5;
    QPushButton *btn6;
    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;
    QPushButton *btn0;
    QPushButton *btnDot;
    QPushButton *btnC;
    QFrame *frame;
    QPushButton *btnPay;
    QPushButton *btnReset;
    QPushButton *btnInvoice;
    QPushButton *btnRemove;
    QPushButton *btnExit;
    QPushButton *btnStock;
    QFrame *frame_2;
    QFrame *frame_3;
    QFrame *frm_Subtotal;
    QLabel *label_3;
    QTextEdit *txtTotal;
    QLabel *label_4;
    QTextEdit *txtSubTotal;
    QTextEdit *txtTax;
    QLabel *label_2;
    QFrame *frm_Payment;
    QLabel *lbl_PaymentMethod;
    QLabel *lblCost;
    QLabel *lblChange;
    QTextEdit *txtCost;
    QTextEdit *txtChange;
    QComboBox *comPmethod;
    QPushButton *btnAtbasket;
    QTextEdit *txtSearch;
    QLabel *lbl_Items;
    QLabel *lbl_count;
    QTableView *BaskettableView;
    QTableView *ItemtblView;
    QLabel *imageLabel;
    QMenuBar *menubar;
    QStatusBar *statusbar;
    QButtonGroup *NumberClick;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1374, 816);
        MainWindow->setMaximumSize(QSize(1386, 879));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        MainHeaderlbl = new QLabel(centralwidget);
        MainHeaderlbl->setObjectName("MainHeaderlbl");
        MainHeaderlbl->setGeometry(QRect(20, 0, 901, 61));
        QFont font;
        font.setFamilies({QString::fromUtf8("Calibri")});
        font.setPointSize(40);
        font.setBold(true);
        MainHeaderlbl->setFont(font);
        NumPad_Frame = new QFrame(centralwidget);
        NumPad_Frame->setObjectName("NumPad_Frame");
        NumPad_Frame->setGeometry(QRect(10, 70, 231, 321));
        NumPad_Frame->setMaximumSize(QSize(241, 337));
        NumPad_Frame->setFrameShape(QFrame::WinPanel);
        NumPad_Frame->setFrameShadow(QFrame::Raised);
        NumPad_Frame->setLineWidth(1);
        NumPad_Frame->setMidLineWidth(0);
        btn7 = new QPushButton(NumPad_Frame);
        NumberClick = new QButtonGroup(MainWindow);
        NumberClick->setObjectName("NumberClick");
        NumberClick->addButton(btn7);
        btn7->setObjectName("btn7");
        btn7->setGeometry(QRect(10, 0, 70, 75));
        QFont font1;
        font1.setPointSize(22);
        font1.setBold(true);
        btn7->setFont(font1);
        btn8 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn8);
        btn8->setObjectName("btn8");
        btn8->setGeometry(QRect(80, 0, 70, 75));
        btn8->setFont(font1);
        btn9 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn9);
        btn9->setObjectName("btn9");
        btn9->setGeometry(QRect(150, 0, 70, 75));
        btn9->setFont(font1);
        btn4 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn4);
        btn4->setObjectName("btn4");
        btn4->setGeometry(QRect(10, 80, 70, 75));
        btn4->setFont(font1);
        btn5 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn5);
        btn5->setObjectName("btn5");
        btn5->setGeometry(QRect(80, 80, 70, 75));
        btn5->setFont(font1);
        btn6 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn6);
        btn6->setObjectName("btn6");
        btn6->setGeometry(QRect(150, 80, 70, 75));
        btn6->setFont(font1);
        btn1 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn1);
        btn1->setObjectName("btn1");
        btn1->setGeometry(QRect(10, 160, 70, 75));
        btn1->setFont(font1);
        btn2 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn2);
        btn2->setObjectName("btn2");
        btn2->setGeometry(QRect(80, 160, 70, 75));
        btn2->setFont(font1);
        btn3 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn3);
        btn3->setObjectName("btn3");
        btn3->setGeometry(QRect(150, 160, 70, 75));
        btn3->setFont(font1);
        btn0 = new QPushButton(NumPad_Frame);
        NumberClick->addButton(btn0);
        btn0->setObjectName("btn0");
        btn0->setGeometry(QRect(10, 240, 70, 75));
        btn0->setFont(font1);
        btnDot = new QPushButton(NumPad_Frame);
        btnDot->setObjectName("btnDot");
        btnDot->setGeometry(QRect(80, 240, 70, 75));
        QFont font2;
        font2.setPointSize(24);
        font2.setBold(true);
        btnDot->setFont(font2);
        btnC = new QPushButton(NumPad_Frame);
        btnC->setObjectName("btnC");
        btnC->setGeometry(QRect(150, 240, 70, 75));
        btnC->setFont(font1);
        frame = new QFrame(centralwidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(10, 400, 231, 371));
        frame->setFrameShape(QFrame::Box);
        frame->setFrameShadow(QFrame::Raised);
        btnPay = new QPushButton(frame);
        btnPay->setObjectName("btnPay");
        btnPay->setGeometry(QRect(9, 10, 211, 57));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Calibri")});
        font3.setPointSize(24);
        font3.setBold(true);
        btnPay->setFont(font3);
        btnReset = new QPushButton(frame);
        btnReset->setObjectName("btnReset");
        btnReset->setGeometry(QRect(10, 70, 211, 57));
        btnReset->setFont(font3);
        btnInvoice = new QPushButton(frame);
        btnInvoice->setObjectName("btnInvoice");
        btnInvoice->setGeometry(QRect(10, 130, 211, 57));
        btnInvoice->setFont(font3);
        btnRemove = new QPushButton(frame);
        btnRemove->setObjectName("btnRemove");
        btnRemove->setGeometry(QRect(10, 190, 211, 57));
        QFont font4;
        font4.setFamilies({QString::fromUtf8("Calibri")});
        font4.setPointSize(22);
        font4.setBold(true);
        btnRemove->setFont(font4);
        btnExit = new QPushButton(frame);
        btnExit->setObjectName("btnExit");
        btnExit->setGeometry(QRect(10, 310, 211, 57));
        btnExit->setFont(font3);
        QIcon icon(QIcon::fromTheme(QString::fromUtf8("application-exit")));
        btnExit->setIcon(icon);
        btnStock = new QPushButton(frame);
        btnStock->setObjectName("btnStock");
        btnStock->setGeometry(QRect(10, 250, 211, 57));
        btnStock->setFont(font3);
        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(250, 400, 1111, 371));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        frame_3 = new QFrame(frame_2);
        frame_3->setObjectName("frame_3");
        frame_3->setGeometry(QRect(10, 10, 1091, 361));
        frame_3->setFrameShape(QFrame::Box);
        frame_3->setFrameShadow(QFrame::Raised);
        frm_Subtotal = new QFrame(frame_3);
        frm_Subtotal->setObjectName("frm_Subtotal");
        frm_Subtotal->setGeometry(QRect(40, 120, 451, 211));
        frm_Subtotal->setFrameShape(QFrame::Box);
        frm_Subtotal->setFrameShadow(QFrame::Raised);
        label_3 = new QLabel(frm_Subtotal);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(30, 90, 111, 31));
        QFont font5;
        font5.setFamilies({QString::fromUtf8("Calibri")});
        font5.setPointSize(20);
        font5.setBold(true);
        label_3->setFont(font5);
        txtTotal = new QTextEdit(frm_Subtotal);
        txtTotal->setObjectName("txtTotal");
        txtTotal->setGeometry(QRect(160, 140, 201, 41));
        QFont font6;
        font6.setFamilies({QString::fromUtf8("Calibri")});
        font6.setPointSize(17);
        font6.setBold(true);
        txtTotal->setFont(font6);
        label_4 = new QLabel(frm_Subtotal);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(30, 140, 111, 31));
        label_4->setFont(font5);
        txtSubTotal = new QTextEdit(frm_Subtotal);
        txtSubTotal->setObjectName("txtSubTotal");
        txtSubTotal->setGeometry(QRect(160, 40, 200, 41));
        txtSubTotal->setFont(font6);
        txtSubTotal->setFrameShape(QFrame::StyledPanel);
        txtTax = new QTextEdit(frm_Subtotal);
        txtTax->setObjectName("txtTax");
        txtTax->setGeometry(QRect(160, 90, 201, 41));
        txtTax->setFont(font6);
        label_2 = new QLabel(frm_Subtotal);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(30, 40, 111, 31));
        label_2->setFont(font5);
        frm_Payment = new QFrame(frame_3);
        frm_Payment->setObjectName("frm_Payment");
        frm_Payment->setGeometry(QRect(540, 120, 451, 211));
        frm_Payment->setFrameShape(QFrame::Box);
        frm_Payment->setFrameShadow(QFrame::Raised);
        lbl_PaymentMethod = new QLabel(frm_Payment);
        lbl_PaymentMethod->setObjectName("lbl_PaymentMethod");
        lbl_PaymentMethod->setGeometry(QRect(20, 40, 201, 31));
        lbl_PaymentMethod->setFont(font5);
        lblCost = new QLabel(frm_Payment);
        lblCost->setObjectName("lblCost");
        lblCost->setGeometry(QRect(20, 90, 111, 31));
        lblCost->setFont(font5);
        lblChange = new QLabel(frm_Payment);
        lblChange->setObjectName("lblChange");
        lblChange->setGeometry(QRect(20, 140, 111, 31));
        lblChange->setFont(font5);
        txtCost = new QTextEdit(frm_Payment);
        txtCost->setObjectName("txtCost");
        txtCost->setGeometry(QRect(230, 90, 201, 41));
        txtCost->setFont(font6);
        txtChange = new QTextEdit(frm_Payment);
        txtChange->setObjectName("txtChange");
        txtChange->setEnabled(true);
        txtChange->setGeometry(QRect(230, 140, 201, 41));
        txtChange->setFont(font6);
        txtChange->setReadOnly(true);
        comPmethod = new QComboBox(frm_Payment);
        comPmethod->addItem(QString());
        comPmethod->addItem(QString());
        comPmethod->setObjectName("comPmethod");
        comPmethod->setGeometry(QRect(230, 40, 201, 41));
        comPmethod->setFont(font5);
        btnAtbasket = new QPushButton(frame_3);
        btnAtbasket->setObjectName("btnAtbasket");
        btnAtbasket->setGeometry(QRect(760, 10, 141, 51));
        QFont font7;
        font7.setFamilies({QString::fromUtf8("Calibri")});
        font7.setPointSize(16);
        font7.setBold(true);
        btnAtbasket->setFont(font7);
        txtSearch = new QTextEdit(frame_3);
        txtSearch->setObjectName("txtSearch");
        txtSearch->setGeometry(QRect(10, 10, 541, 51));
        QFont font8;
        font8.setFamilies({QString::fromUtf8("Calibri")});
        font8.setPointSize(14);
        font8.setBold(true);
        txtSearch->setFont(font8);
        txtSearch->setFrameShape(QFrame::StyledPanel);
        lbl_Items = new QLabel(centralwidget);
        lbl_Items->setObjectName("lbl_Items");
        lbl_Items->setGeometry(QRect(1070, 40, 51, 21));
        lbl_Items->setFont(font7);
        lbl_count = new QLabel(centralwidget);
        lbl_count->setObjectName("lbl_count");
        lbl_count->setGeometry(QRect(1130, 40, 21, 20));
        QFont font9;
        font9.setPointSize(14);
        font9.setBold(true);
        lbl_count->setFont(font9);
        BaskettableView = new QTableView(centralwidget);
        BaskettableView->setObjectName("BaskettableView");
        BaskettableView->setGeometry(QRect(1020, 70, 331, 321));
        BaskettableView->setFrameShape(QFrame::StyledPanel);
        ItemtblView = new QTableView(centralwidget);
        ItemtblView->setObjectName("ItemtblView");
        ItemtblView->setGeometry(QRect(250, 70, 761, 321));
        imageLabel = new QLabel(centralwidget);
        imageLabel->setObjectName("imageLabel");
        imageLabel->setGeometry(QRect(1020, 30, 39, 37));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1374, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        MainHeaderlbl->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" color:#ff7f43;\">SUPERMARKET CHECKOUT SIMULATION</span></p></body></html>", nullptr));
        btn7->setText(QCoreApplication::translate("MainWindow", "7", nullptr));
        btn8->setText(QCoreApplication::translate("MainWindow", "8", nullptr));
        btn9->setText(QCoreApplication::translate("MainWindow", "9", nullptr));
        btn4->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        btn5->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        btn6->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        btn1->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        btn2->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        btn3->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        btn0->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        btnDot->setText(QCoreApplication::translate("MainWindow", ".", nullptr));
        btnC->setText(QCoreApplication::translate("MainWindow", "C", nullptr));
        btnPay->setText(QCoreApplication::translate("MainWindow", "PAY", nullptr));
        btnReset->setText(QCoreApplication::translate("MainWindow", "RESET", nullptr));
        btnInvoice->setText(QCoreApplication::translate("MainWindow", "INVOICE", nullptr));
        btnRemove->setText(QCoreApplication::translate("MainWindow", "REMOVE ITEM", nullptr));
        btnExit->setText(QCoreApplication::translate("MainWindow", "EXIT", nullptr));
        btnStock->setText(QCoreApplication::translate("MainWindow", "STOCK", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Tax", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Total", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Sub Total", nullptr));
        lbl_PaymentMethod->setText(QCoreApplication::translate("MainWindow", "Payment Method", nullptr));
        lblCost->setText(QCoreApplication::translate("MainWindow", "Cash", nullptr));
        lblChange->setText(QCoreApplication::translate("MainWindow", "Change", nullptr));
        comPmethod->setItemText(0, QCoreApplication::translate("MainWindow", "Cash", nullptr));
        comPmethod->setItemText(1, QCoreApplication::translate("MainWindow", "Card", nullptr));

        btnAtbasket->setText(QCoreApplication::translate("MainWindow", "Add To Basket", nullptr));
        lbl_Items->setText(QCoreApplication::translate("MainWindow", "Items", nullptr));
        lbl_count->setText(QString());
        imageLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
