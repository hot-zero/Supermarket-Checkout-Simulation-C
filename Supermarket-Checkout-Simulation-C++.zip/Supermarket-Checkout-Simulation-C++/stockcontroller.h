#ifndef STOCKCONTROLLER_H
#define STOCKCONTROLLER_H

#include <QDialog>
#include <QStandardItemModel>
#include <QShowEvent>
#include "Item.h"
#include "tableviewmanager.h"

namespace Ui {
class StockController;
}

class StockController : public QDialog
{
    Q_OBJECT

public:
    QVector<Item> items; // Member variable for items

    explicit StockController(QWidget *parent = nullptr);
    ~StockController();
    void setupTableView();  // Declare the function
    void on_txtSearch_textChanged();
    void on_btn_NItem_clicked();
    void updateDetails(const QString& id, const QString& pName, const QString& pDescription,
                       const QString& pBarcode, double pPrice, const QString& pQuantity, const QString& pCategory);
private slots:
    void on_btn_StockExit_clicked();
   // void on_tbl_Scontroller_activated();
    void showSelectedItemDetails(const QModelIndex &index);
    void on_txtSearchStock_textChanged();
    void on_btn_Delete_clicked();
    void on_btn_Save_clicked();
    void on_btnResetStock_clicked();

private:
    QList<Item> item;
    Ui::StockController *ui;
    void setupTable();
    void updateTableView(const std::vector<Item>& updatedItems);
    TableViewManager tableViewManager;

};

#endif // STOCKCONTROLLER_H
