
#ifndef STOCKDATA_H
#define STOCKDATA_H

#include <QList>
#include "Item.h"

class StockData {
public:
    static StockData& getInstance() {
        static StockData instance;
        return instance;
    }

    QList<Item*> items;

private:
    StockData() {} // Constructor is private for singleton

public:
    StockData(StockData const&) = delete;
    void operator=(StockData const&) = delete;
};

#endif // STOCKDATA_H
