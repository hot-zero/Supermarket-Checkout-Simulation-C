#include "invoicecontroller.h"
#include "qdatetime.h"
#include "qpainter.h"
#include "qstandarditemmodel.h"
#include "tableviewmanager.h"
#include "ui_invoicecontroller.h"
#include <QRandomGenerator>
#include "mainwindow.h"
#include "PaymentProcessor.h"
#include <QPrinter>
#include <QPrintDialog>
#include <QPixmap>
#include <QFile>



InvoiceController::InvoiceController(MainWindow* mainWindow, PaymentProcessor* paymentProcessor,QWidget* parent)
    : QDialog(parent),
    ui(new Ui::InvoiceController),
    tableViewManager(new TableViewManager(this)),
    paymentProcessor(paymentProcessor),
    mainWindow(mainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Invoice");  //  header text
    setupInvoicetblView();
    updateDateLabel();
    OrderNumber();
    onPaymentSuccessful(PaymentAmount, sum, tax, change, PaymentMethod);

    // Connect the label's linkActivated signal to the on_Datelbl_linkActivated() slot
    connect(ui->Datelbl, &QLabel::linkActivated, this, &InvoiceController::updateDateLabel);
    connect(mainWindow, &MainWindow::basketModelUpdated, this, &InvoiceController::updateInvoiceBasketModel);
    connect(paymentProcessor, &PaymentProcessor::PaymentSuccessful, this, &InvoiceController::onPaymentSuccessful);

    //----------------Buttons font and background color style-------------------

    ui->Printbtn->setStyleSheet("background-color: green;color: white;");
    ui->InvoiceExitbtn->setStyleSheet("background-color: red;color: white");
    //----------------------------End Buttons Style----------------------------

    QString iconPath = "/Supermarket-Checkout/icons/invoice.png"; // Form icon
    QIcon icon(iconPath);

    // Check if the file exists
    if (!QFile::exists(iconPath)) {
        qDebug() << "Icon file does not exist: " << iconPath;
    } else {
        this->setWindowIcon(icon);
    }

}
InvoiceController::~InvoiceController()
{
    delete ui;
}

void InvoiceController::onPaymentSuccessful(double PaymentAmount, double sum, double tax, double change,QString PaymentMethod)
{
    QString poundSign = QString::fromUtf8("\u00A3"); // Unicode character for pound sign

    if (PaymentAmount==0)
    {
        ui->Datelbl->hide();
        ui->OrderNumlbl->hide();
    }

    if (PaymentMethod=="Cash"){
        // Update labels with descriptive text
        ui->InvCombolbl->setText("Payment Method:  " + PaymentMethod);
        ui->InvTotallbl->setText("Total Amount:  " + poundSign + QString::number(PaymentAmount, 'f', 2));
        ui->InvTaxlbl->setText("Tax amount:  " + poundSign + QString::number(tax, 'f', 2));
        ui->InvCashlbl->setText("Cash Received:  " + poundSign + QString::number(sum, 'f', 2));
        ui->InvChangelbl->setText("Change Due:  " + poundSign + QString::number(change, 'f', 2));
    }
    else {
        ui->InvCombolbl->setText("Payment Method:  " + PaymentMethod);
        ui->InvTotallbl->setText("Total Amount:  " + poundSign + QString::number(PaymentAmount, 'f', 2));
        ui->InvTaxlbl->setText("Tax amount:  " + poundSign + QString::number(tax, 'f', 2));

    }
}

void InvoiceController::setupInvoicetblView()
{

    tableViewManager->setupBaskettblView(ui->InvoicetblView);
}

void InvoiceController::updateInvoiceBasketModel(QStandardItemModel* basketModel)
{

    // A model for the Invoice QTableView in InvoiceController
    QStandardItemModel* invoiceModel = dynamic_cast<QStandardItemModel*>(ui->InvoicetblView->model());

    // Clear the existing data in the Invoice model
    invoiceModel->clear();
    // Set header labels for the columns in the invoiceModel
    QStringList headerLabels;
    headerLabels << "Item" << "Barcode" << "Price";
    invoiceModel->setHorizontalHeaderLabels(headerLabels);

    // Copy the data from the basket model to the Invoice model
    for (int row = 0; row < basketModel->rowCount(); ++row) {
        QList<QStandardItem*> rowData;
        for (int col = 0; col < basketModel->columnCount(); ++col) {
            rowData << new QStandardItem(basketModel->item(row, col)->text());
        }
        invoiceModel->appendRow(rowData);
    }

}

void InvoiceController::on_InvoiceExitbtn_clicked()
{
    // Close the InvoiceController form
    close();
}
void InvoiceController::on_Printbtn_clicked()
{
    // Create a printer object
    QPrinter printer;
    // Adjust the index based on your actual column index for Pound sign
    const int priceColumnIndex = 2;

    // Set the title for the printout
    printer.setDocName("Invoice Printout");

    // Set paper size to 100mm width
    printer.setPageSize(QPageSize(QSizeF(100.0, 800.0), QPageSize::Millimeter));

    // Create a print dialog and set the printer
    QPrintDialog printDialog(&printer, this);

    // If the user clicks "Cancel" in the print dialog, return
    if (printDialog.exec() == QDialog::Rejected) {
        return;
    }

    // Create a painter for drawing on the printer
    QPainter painter(&printer);

    // Start a new page
    painter.begin(&printer);

    // Draw a frame around the content
    QRect frameRect(2, 2, 400, 800);
    painter.drawRect(frameRect);

    // Print the title
    QFont titleFont;
    titleFont.setPointSize(12);
    painter.setFont(titleFont);
    painter.drawText(100, 20, "SUPERMARKET INVOICE");
    painter.drawText(100, 35, "================");

    // Print the column titles
    QStandardItemModel* model = qobject_cast<QStandardItemModel*>(ui->InvoicetblView->model());
    if (model) {
        int startY = 110;  // Adjust the starting Y coordinate based on your layout

        // Column titles
        QFont labelFont;
        labelFont.setPointSize(12);
        painter.setFont(labelFont);

        painter.drawText(20, startY, "Product");
        painter.drawText(170, startY, "Barcode");
        painter.drawText(320, startY, "Price");

        int rowCount = model->rowCount();
        int colCount = model->columnCount();

        for (int row = 0; row < rowCount; ++row) {
            for (int col = 0; col < colCount; ++col) {
                // Check if the column is the price column
                if (col == priceColumnIndex) {  // Replace 'priceColumnIndex' with the actual index of the price column
                    QString itemText = "£" + model->index(row, col).data().toString();  // Add £ symbol
                    painter.drawText(20 + col * 150, startY + (row + 1) * 20, itemText);
                } else {
                    QString itemText = model->index(row, col).data().toString();
                    painter.drawText(20 + col * 150, startY + (row + 1) * 20, itemText);
                }
            }
        }
    }

    // Print labels (You may need to adjust the coordinates based on your layout)
    QFont labelFont;
    labelFont.setPointSize(12);
    painter.setFont(labelFont);

    // Print "Order Number:" label
    painter.drawText(20, 60, "Order Number:");
    // Print the actual order number
    painter.drawText(150, 60, ui->OrderNumlbl->text());
    // Print the actual Date & Time
    painter.drawText(20, 80, "Date & Time:");
    painter.drawText(150, 80, ui->Datelbl->text());

    painter.drawText(20, 600, ui->InvCombolbl->text());
    painter.drawText(20, 625, ui->InvTotallbl->text());
    painter.drawText(20, 650, ui->InvTaxlbl->text());
    painter.drawText(20, 675, ui->InvCashlbl->text());
    painter.drawText(20, 700, ui->InvChangelbl->text());

    // End the painting
    painter.end();
    //Close Form
    close();
}

void InvoiceController::updateDateLabel()
{
    // Get the current date and time
    QDateTime currentDateTime = QDateTime::currentDateTime();

    // Convert the QDateTime to a QString with the UK format
    QString formattedDateTime = currentDateTime.toString("dd/MM/yyyy    hh:mm:ss");

    // Set the text of the label to the formatted date and time
    ui->Datelbl->setText(formattedDateTime);
}

void InvoiceController::OrderNumber()
{
    // Generate a random order number
    int orderNumber = QRandomGenerator::global()->bounded(100000, 999999);
    // Convert the order number to a QString
    QString orderNumberString = QString::number(orderNumber);
    // Set the label text to the generated order number
    ui->OrderNumlbl->setText(orderNumberString);
}

