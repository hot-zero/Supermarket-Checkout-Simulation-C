#include "product.h"





Product::Product(QString id, QString itemName, QString description, QString barcode, double price, QString quantity, QString category) {
    this->id = id;
    this->itemName = itemName;
    this->description = description;
    this->barcode = barcode;
    this->price = price; // Make sure this line is correct
    this->quantity = quantity;
    this->category = category;
}

Product::~Product() {
}

QString Product::getProductId() const {
    return id;
}

QString Product::getProductName() const {
    return itemName;
}

QString Product::getProductDescription() const {
    return description;
}

QString Product::getProductBarcode() const {
    return barcode;
}

double Product::getProductPrice() const {
    return price;
}

QString Product::getProductQuantity() const {
    return quantity;
}

QString Product::getProductCategory() const {
    return category;
}

void Product::setProductCategory(QString newProductCategory) {
    category = newProductCategory;
}

// Implementation of the FoodProduct class
FoodProduct::FoodProduct(const QString& id, const QString& name, const QString& description, const QString& barcode, double price, const QString& quantity, QString category)
    : Product(id, name, description, barcode, price, quantity, category) {
    // constructor implementation, if any specific to FoodProduct
}

// Implementation of ElectronicProduct class
ElectronicProduct::ElectronicProduct(const QString& id, const QString& name, const QString& description, const QString& barcode, double price, const QString& quantity, QString category)
    : Product(id, name, description, barcode, price, quantity, category) {
    // constructor implementation, if any specific to ElectronicProduct
}
