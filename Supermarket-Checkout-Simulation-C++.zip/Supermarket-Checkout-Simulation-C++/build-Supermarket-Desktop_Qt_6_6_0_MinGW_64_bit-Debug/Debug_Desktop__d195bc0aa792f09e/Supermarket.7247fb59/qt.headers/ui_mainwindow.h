/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QFrame *NumPad_Frame;
    QPushButton *btn7;
    QPushButton *btn8;
    QPushButton *btn9;
    QPushButton *btn4;
    QPushButton *btn5;
    QPushButton *btn6;
    QPushButton *btn1;
    QPushButton *btn2;
    QPushButton *btn3;
    QPushButton *btn0;
    QPushButton *btnDot;
    QPushButton *btnC;
    QFrame *frame;
    QPushButton *btnPay;
    QPushButton *btnReset;
    QPushButton *btnInvoice;
    QPushButton *btnRemove;
    QPushButton *btnExit;
    QPushButton *btnStock;
    QTableView *tableView;
    QTableView *tableView_2;
    QFrame *frame_2;
    QFrame *frame_3;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QTextEdit *textEdit;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1374, 821);
        MainWindow->setMaximumSize(QSize(1386, 879));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 0, 501, 61));
        NumPad_Frame = new QFrame(centralwidget);
        NumPad_Frame->setObjectName("NumPad_Frame");
        NumPad_Frame->setGeometry(QRect(10, 70, 231, 321));
        NumPad_Frame->setMaximumSize(QSize(241, 337));
        NumPad_Frame->setFrameShape(QFrame::WinPanel);
        NumPad_Frame->setFrameShadow(QFrame::Raised);
        btn7 = new QPushButton(NumPad_Frame);
        btn7->setObjectName("btn7");
        btn7->setGeometry(QRect(10, 0, 70, 75));
        QFont font;
        font.setPointSize(22);
        font.setBold(true);
        btn7->setFont(font);
        btn8 = new QPushButton(NumPad_Frame);
        btn8->setObjectName("btn8");
        btn8->setGeometry(QRect(80, 0, 70, 75));
        btn8->setFont(font);
        btn9 = new QPushButton(NumPad_Frame);
        btn9->setObjectName("btn9");
        btn9->setGeometry(QRect(150, 0, 70, 75));
        btn9->setFont(font);
        btn4 = new QPushButton(NumPad_Frame);
        btn4->setObjectName("btn4");
        btn4->setGeometry(QRect(10, 80, 70, 75));
        btn4->setFont(font);
        btn5 = new QPushButton(NumPad_Frame);
        btn5->setObjectName("btn5");
        btn5->setGeometry(QRect(80, 80, 70, 75));
        btn5->setFont(font);
        btn6 = new QPushButton(NumPad_Frame);
        btn6->setObjectName("btn6");
        btn6->setGeometry(QRect(150, 80, 70, 75));
        btn6->setFont(font);
        btn1 = new QPushButton(NumPad_Frame);
        btn1->setObjectName("btn1");
        btn1->setGeometry(QRect(10, 160, 70, 75));
        btn1->setFont(font);
        btn2 = new QPushButton(NumPad_Frame);
        btn2->setObjectName("btn2");
        btn2->setGeometry(QRect(80, 160, 70, 75));
        btn2->setFont(font);
        btn3 = new QPushButton(NumPad_Frame);
        btn3->setObjectName("btn3");
        btn3->setGeometry(QRect(150, 160, 70, 75));
        btn3->setFont(font);
        btn0 = new QPushButton(NumPad_Frame);
        btn0->setObjectName("btn0");
        btn0->setGeometry(QRect(10, 240, 70, 75));
        btn0->setFont(font);
        btnDot = new QPushButton(NumPad_Frame);
        btnDot->setObjectName("btnDot");
        btnDot->setGeometry(QRect(80, 240, 70, 75));
        QFont font1;
        font1.setPointSize(24);
        font1.setBold(true);
        btnDot->setFont(font1);
        btnC = new QPushButton(NumPad_Frame);
        btnC->setObjectName("btnC");
        btnC->setGeometry(QRect(150, 240, 70, 75));
        btnC->setFont(font);
        frame = new QFrame(centralwidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(10, 400, 231, 371));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        btnPay = new QPushButton(frame);
        btnPay->setObjectName("btnPay");
        btnPay->setGeometry(QRect(9, 10, 211, 57));
        btnPay->setFont(font);
        btnReset = new QPushButton(frame);
        btnReset->setObjectName("btnReset");
        btnReset->setGeometry(QRect(10, 70, 211, 57));
        btnReset->setFont(font);
        btnInvoice = new QPushButton(frame);
        btnInvoice->setObjectName("btnInvoice");
        btnInvoice->setGeometry(QRect(10, 130, 211, 57));
        btnInvoice->setFont(font);
        btnRemove = new QPushButton(frame);
        btnRemove->setObjectName("btnRemove");
        btnRemove->setGeometry(QRect(10, 190, 211, 57));
        btnRemove->setFont(font);
        btnExit = new QPushButton(frame);
        btnExit->setObjectName("btnExit");
        btnExit->setGeometry(QRect(10, 310, 211, 57));
        btnExit->setFont(font);
        btnStock = new QPushButton(frame);
        btnStock->setObjectName("btnStock");
        btnStock->setGeometry(QRect(10, 250, 211, 57));
        btnStock->setFont(font);
        tableView = new QTableView(centralwidget);
        tableView->setObjectName("tableView");
        tableView->setGeometry(QRect(250, 70, 631, 321));
        tableView_2 = new QTableView(centralwidget);
        tableView_2->setObjectName("tableView_2");
        tableView_2->setGeometry(QRect(890, 70, 471, 321));
        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(250, 400, 1111, 371));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        frame_3 = new QFrame(frame_2);
        frame_3->setObjectName("frame_3");
        frame_3->setGeometry(QRect(20, 120, 451, 231));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        label_2 = new QLabel(frame_3);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(10, 30, 111, 31));
        QFont font2;
        font2.setPointSize(18);
        font2.setBold(true);
        label_2->setFont(font2);
        label_3 = new QLabel(frame_3);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(10, 80, 111, 31));
        label_3->setFont(font2);
        label_4 = new QLabel(frame_3);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(10, 130, 111, 31));
        label_4->setFont(font2);
        textEdit = new QTextEdit(frame_3);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(160, 20, 104, 70));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1374, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:26pt; font-weight:700; color:#ff5500;\">SUPERMARKET CHECKOUT</span></p></body></html>", nullptr));
        btn7->setText(QCoreApplication::translate("MainWindow", "7", nullptr));
        btn8->setText(QCoreApplication::translate("MainWindow", "8", nullptr));
        btn9->setText(QCoreApplication::translate("MainWindow", "9", nullptr));
        btn4->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        btn5->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        btn6->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        btn1->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        btn2->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        btn3->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        btn0->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        btnDot->setText(QCoreApplication::translate("MainWindow", ".", nullptr));
        btnC->setText(QCoreApplication::translate("MainWindow", "C", nullptr));
        btnPay->setText(QCoreApplication::translate("MainWindow", "PAY", nullptr));
        btnReset->setText(QCoreApplication::translate("MainWindow", "RESET", nullptr));
        btnInvoice->setText(QCoreApplication::translate("MainWindow", "INVOICE", nullptr));
        btnRemove->setText(QCoreApplication::translate("MainWindow", "REMOVE ITEM", nullptr));
        btnExit->setText(QCoreApplication::translate("MainWindow", "EXIT", nullptr));
        btnStock->setText(QCoreApplication::translate("MainWindow", "STOCK", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Sub Total", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Tax", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Total", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
