#ifndef CARDCONTROLLER_H
#define CARDCONTROLLER_H

#include "PaymentProcessor.h"
#include "qtextedit.h"
#include <QDialog>
#include "PaymentProcessor.h"
#include "invoicecontroller.h"

namespace Ui {
class CardController;
}

class CardController : public QDialog
{
    Q_OBJECT

public:
    explicit CardController(QWidget *parent = nullptr, PaymentProcessor* processor = nullptr);
    ~CardController();
signals:

    // Define a signal with parameters paymentAmount and paymentMethod
    void CardPaymentSuccessful(double PaymentAmount,QString &PaymentMethod);

private slots:
    void on_btnExitCard_clicked();
    void on_btnPayCard_clicked();
    void on_btnResetCard_clicked();

private:
    Ui::CardController *ui;
    PaymentProcessor* paymentProcessor;
    InvoiceController* invoiceController;
    QTextEdit* txtCost;
    QTextEdit* txtTotal;
    QTextEdit* txtChange;
    QComboBox* comPmethod;
    QTextEdit*txtCardNum;
    QTextEdit* txtExpiry;
    QTextEdit* txtCVV2;
    QTextEdit* txtFullName;
    QString PaymentMethod;
    double PaymentAmount;

};

#endif // CARDCONTROLLER_H
