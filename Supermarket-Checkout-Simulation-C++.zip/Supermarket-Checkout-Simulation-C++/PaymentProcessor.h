#ifndef PAYMENTPROCESSOR_H
#define PAYMENTPROCESSOR_H
#include "qcombobox.h"
#include "qlabel.h"
#include "qtableview.h"
#include "qtextedit.h"

// Forward declaration
class InvoiceController;
// Forward declarations
class MainWindow;
class PaymentProcessor : public QObject
{
    Q_OBJECT
public:
    PaymentProcessor();
    void update_ItemCost(QTableView* BaskettblView, QTextEdit* txtSubTotal, QTextEdit* txtTax, QTextEdit* txtTotal);
    void PayButton(QTextEdit* txtTotal, QTextEdit* txtCost, QTextEdit* txtChange, QComboBox* comPayment);
    static void ClearData(QTableView* BaskettblView, QTableView* ItemtblView, QTextEdit* txtCost,QTextEdit* txtSubTotal,QTextEdit* txtTax
                          ,QTextEdit* txtTotal,QTextEdit* txtChange,QComboBox* comPmethod,QLabel* lbl_count);

    double subtotal = 0.0;
    double taxRate = 0.20; // 20% tax rate
    double tax;

signals:
    // Define a signal with parameters PaymentAmount, sum, and change
    void PaymentSuccessful(double PaymentAmount, double sum, double tax, double change, QString &PaymentMethod);
private:

    QTableView* BaskettblView;
    QTableView* ItemtblView;
    QTextEdit* txtCost;
    QTextEdit* txtSubTotal;
    QTextEdit* txtTax;
    QTextEdit* txtTotal;
    QTextEdit* txtChange;
    QComboBox* comPmethod;
    QLabel* lbl_count;
    InvoiceController *invoiceController;
    PaymentProcessor* paymentProcessor;
    MainWindow* mainWindow;
};

#endif // PAYMENTPROCESSOR_H
