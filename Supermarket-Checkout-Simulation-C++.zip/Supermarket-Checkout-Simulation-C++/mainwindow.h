#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "PaymentProcessor.h"
#include "qtextedit.h"
#include "tableviewmanager.h"
#include "ui_mainwindow.h"
#include <QMainWindow>
#include <QStandardItemModel>
#include <QTableView>
#include <QVBoxLayout>
#include "Item.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

signals:
    void basketModelUpdated(QStandardItemModel* basketModel);
    // Define a signal with parameters paymentAmount, sum, and change
    void PaymentSuccessful(double PaymentAmount, double sum,double tax, double change,QString &PaymentMethod);


public:
    // Declare the 'items' list here
    QList<Item> items;
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void update_ItemCost(QTableView* BaskettblView, QTextEdit* txtSubTotal, QTextEdit* txtTax, QTextEdit* txtTotal);
    void addItemToModel(int id, const QString &item, const QString &description, const QString &barcode, const QString &price, const QString &quantity);
    void UpdateItemCost();
    void setupTableView();
    void setupBasketTableView();
    void onStockFormClosed();
    void ClearAndReset();
    double PaymentAmount;
    double sum;
    double change;
    double tax;

private slots:
    void onNumberButtonClicked(int number); // Slot for number buttons
    void onDotButtonClicked(); // Slot for decimal point button
    void onClearButtonClicked(); // Slot for clear button
    void on_comPmethod_activated(int index);
    void on_btnAtbasket_clicked();
    void on_btnExit_clicked(); 
    void on_btnPay_clicked();
    void on_txtSearch_textChanged();  
    void on_btnRemove_clicked();
    void on_lbl_count_linkActivated();
    void on_btnStock_clicked();
    void on_btnReset_clicked();
    void on_btnInvoice_clicked();
    void onInvoiceFormClosed();

private:
    Ui::MainWindow *ui;
    QTableView *ItemtblView;
    QStandardItemModel *model;
    TableViewManager *tableViewManager;
    PaymentProcessor *paymentProcessor;
    InvoiceController *invoiceController;
    bool invoiceFormOpen = false;

};
#endif // MAINWINDOW_H
